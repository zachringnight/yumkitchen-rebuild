# Coder-Ready Build Plan for yum! + Patticake Acquisition System

Do **not** give AI coders the whole marketing strategy as one prompt. Break it into **bounded projects**, each with a specific output, test criteria, and dependency chain.

---

# Program Name

## yum! + Patticake Digital Acquisition Engine

**Goal:** Build the digital infrastructure that turns search, social, email, and local demand into measurable orders, catering leads, cake requests, shipped Patticake orders, and repeat customers.

---

# Recommended Project Board Columns

1. Backlog
2. Ready for AI Coder
3. In Progress
4. Needs Human Review
5. QA
6. Blocked
7. Ready to Deploy
8. Done

---

# Priority Rules

| Priority | Meaning |
|---|---|
| P0 | Must happen before paid traffic or major campaign launch |
| P1 | Needed for first 30–60 days of acquisition |
| P2 | Growth layer after the foundation is working |
| P3 | Optimization, personalization, and nice-to-have expansion |

---

# Build Sequence

## Phase 1 — Foundation

1. Site audit and source-of-truth cleanup
2. Tracking and attribution setup
3. Conversion architecture
4. Core landing page templates
5. Patticake funnel cleanup
6. Catering lead funnel

## Phase 2 — Acquisition Pages

7. Location SEO pages
8. Cake occasion pages
9. Corporate gifting page
10. Wedding/event cake page
11. Gift card page

## Phase 3 — Growth Loops

12. Email/SMS automation setup
13. Referral/review capture
14. Paid media landing pages
15. Reporting dashboard
16. CRO testing system

---

# Project 0 — AI Coder Operating Rules

## Objective

Make sure every AI coder works in small, testable chunks and does not destroy the existing site.

## Rules for all AI coders

- Work one ticket at a time.
- Create a branch per ticket.
- Do not redesign the whole site unless the ticket says to.
- Do not change checkout/order flows without explicit approval.
- Do not hard-code tracking IDs in random files; use environment/config variables.
- Use reusable components.
- Preserve brand voice: neighborhood, warm, made-from-scratch, not sterile SaaS.
- Every form must capture UTM parameters.
- Every CTA must be trackable.
- Every landing page must have one primary conversion goal.

## Standard AI Coder Ticket Prompt

```text
You are working on the yum! Kitchen & Bakery / Patticake digital acquisition system.

Goal:
[Insert specific task]

Context:
- yum! drives local restaurant, bakery, takeout, catering, and gift card demand.
- Patticake drives celebration cake, local pickup, shipped cake, corporate gifting, and wedding/event demand.
- We need measurable acquisition, not generic website updates.

Constraints:
- Do not change unrelated pages.
- Preserve existing brand styling unless the task asks for a new component.
- Use reusable components where possible.
- All CTAs must be trackable.
- All forms must capture UTM source, medium, campaign, content, term, page URL, and referrer.
- Add clear acceptance tests.

Deliverables:
1. Files changed.
2. Summary of implementation.
3. QA checklist.
4. Any assumptions or blockers.
```

---

# Project 1 — Current Site Audit + Source of Truth

## Priority

P0

## Objective

Find and document contradictions, dead links, duplicate pages, tracking gaps, and conversion leaks across yumkitchen.com and patticake.com.

## Tasks

### Task 1.1 — Crawl both sites

**Goal:** Create a complete inventory of public URLs.

**Deliverable:** Spreadsheet or markdown table with URL, page type, primary CTA, broken links, duplicate content, conversion issue, SEO issue.

**Acceptance Criteria:**

- Every major public page is listed.
- All order, form, and contact links are checked.
- Contradictory cake/shipping language is flagged.
- Old cake pages are identified.

### Task 1.2 — Create source-of-truth messaging doc

**Deliverable:** `/docs/source-of-truth.md`

**Include:**

- Brand positioning for yum!
- Brand positioning for Patticake
- Shipping language
- Local pickup language
- Catering language
- Wedding cake language
- Approved CTAs
- Disallowed CTAs

**Acceptance Criteria:**

- One clear answer for whether Patticake ships.
- One clear answer for whether shipping is checkout or request-based.
- Old language like “we do not ship or deliver” is flagged for replacement or redirect.

---

# Project 2 — Tracking + Attribution Foundation

## Priority

P0

## Objective

Install or verify analytics so all acquisition activity can be measured.

## Core Events

| Event Name | Trigger |
|---|---|
| order_click | User clicks online order button |
| location_directions_click | User clicks directions |
| phone_click | User clicks phone number |
| catering_form_submit | Catering form submitted |
| cake_pickup_form_submit | Cake pickup form submitted |
| patticake_shipping_request_submit | Shipping request submitted |
| corporate_gifting_form_submit | Corporate gifting form submitted |
| wedding_inquiry_submit | Wedding/event form submitted |
| gift_card_click | Gift card CTA clicked |
| email_signup_submit | Email capture submitted |
| sms_signup_submit | SMS opt-in submitted |

## Tasks

### Task 2.1 — Add analytics event map

**Deliverable:** `/docs/analytics-event-map.md`

**Acceptance Criteria:**

- Every primary CTA has a named event.
- Event names are consistent and lowercase.
- UTM parameters are included where relevant.

### Task 2.2 — Implement tracking helper

**Example structure:**

```ts
trackEvent("order_click", {
  location: "st_louis_park",
  page_path: window.location.pathname,
  cta_label: "Order Online",
  destination_url: url,
  utm_source,
  utm_medium,
  utm_campaign
});
```

**Acceptance Criteria:**

- Tracking function works across pages.
- Handles missing analytics gracefully.
- Does not break page navigation.
- Can support GA4, Meta Pixel, or future tools.

### Task 2.3 — Add UTM capture utility

**Acceptance Criteria:**

- Captures `utm_source`, `utm_medium`, `utm_campaign`, `utm_content`, `utm_term`, landing page URL, and referrer.
- Persists for at least the user session.
- Hidden form fields are populated automatically.

---

# Project 3 — Conversion Component System

## Priority

P0

## Objective

Create reusable components for all acquisition pages.

## Components to Build

| Component | Purpose |
|---|---|
| HeroWithCTA | Landing page hero |
| CTAButtonGroup | Primary and secondary CTAs |
| LocationSelector | Send users to nearest yum! |
| OrderButton | Online order link with tracking |
| DirectionsButton | Google Maps link with tracking |
| PhoneButton | Click-to-call with tracking |
| LeadForm | Generic form shell with hidden UTMs |
| FAQBlock | SEO and conversion support |
| SocialProofBlock | Reviews/testimonials |
| MenuCardGrid | Menu/category highlights |
| OccasionCardGrid | Birthday, thank-you, office, wedding, etc. |
| CateringPackageGrid | Catering packages |
| TrustBar | Made from scratch, local pickup, four locations, etc. |
| StickyMobileCTA | Mobile conversion helper |
| AnalyticsTrackedLink | Wrapper for tracked outbound links |

## Tasks

### Task 3.1 — Build CTA tracking wrapper

**Acceptance Criteria:**

- Any CTA can pass event name, CTA label, destination URL, location, and page type.
- Works for internal and external links.
- Opens external order links correctly.

### Task 3.2 — Build reusable lead form

**Fields:** first name, last name, email, phone, company optional, event date optional, occasion, pickup/shipping preference, location preference, message, hidden UTM fields.

**Acceptance Criteria:**

- Required fields validated.
- Spam protection included.
- Form success and error states shown.
- Form submission event fires.
- Data routes to CRM, email, Airtable, Google Sheet, or form backend.

### Task 3.3 — Build sticky mobile CTA

**Acceptance Criteria:**

- On location pages: Order + Directions.
- On catering pages: Get Quote + Call.
- On Patticake pages: Order/Request Cake.
- Does not cover important content.
- Can be disabled per page.

---

# Project 4 — Domain, Redirect, and Information Architecture Cleanup

## Priority

P0

## Objective

Prevent yum! and Patticake pages from competing or contradicting each other.

## Tasks

### Task 4.1 — URL decision map

**Deliverable:** `/docs/url-decision-map.md`

| Current URL | Keep / Redirect / Rewrite | Destination | Reason |
|---|---|---|---|
| Old yum cake page | Redirect | Patticake pickup/shipping page | Avoid contradiction |
| yum catering page | Keep + improve | Same URL | Local SEO value |
| Patticake product page | Keep + improve | Same URL | Hero product page |

**Acceptance Criteria:**

- Every cake-related page has a decision.
- No page says shipping is unavailable if Patticake shipping is active.
- No duplicate pages fight for the same keyword.

### Task 4.2 — Implement redirects

**Acceptance Criteria:**

- 301 redirects used where appropriate.
- Old cake pages route to the correct current Patticake page.
- No redirect chains.
- No 404s on major acquisition paths.

### Task 4.3 — Add canonical tags

**Acceptance Criteria:**

- Duplicate or similar pages have clear canonicals.
- Patticake pages canonicalize to Patticake where appropriate.
- yum! restaurant pages canonicalize to yumkitchen.com.

---

# Project 5 — Patticake Funnel Cleanup

## Priority

P0

## Objective

Make Patticake conversion clear: either direct checkout or request-to-confirm. No mixed signals.

## Decision Required

### Option A — Ecommerce Flow

Use this if customers can pay online immediately.

Primary CTA: **Order a Patticake**

Flow: Product page → checkout → confirmation → email/SMS confirmation

### Option B — Request Flow

Use this if bakery confirmation is needed first.

Primary CTA: **Start a Patticake Request**

Flow: Product page → request form → confirmation message → staff follow-up

## Tasks

### Task 5.1 — Update Patticake product page

**Page Sections:** hero product photo, product name, price, servings, pickup/shipping options, personal message option, primary CTA, FAQ, social proof, corporate gifting CTA, wedding/event CTA.

**Acceptance Criteria:**

- No placeholder/sample review text.
- No contradictory checkout/request copy.
- CTA above the fold.
- Mobile CTA visible.
- Tracking events fire.

### Task 5.2 — Build Patticake request/order form

**Fields:** name, email, phone, pickup or shipping, desired date, recipient name, gift message, quantity, occasion, notes, hidden UTMs.

**Acceptance Criteria:**

- Form event fires.
- Confirmation message explains next step.
- Internal notification goes to bakery/team.
- Submitted data is stored somewhere reliable.
- User receives confirmation email if email system is available.

### Task 5.3 — Build occasion selector

**Occasions:** birthday, thank you, congratulations, sympathy/support, office celebration, holiday, wedding/shower, just because.

**Acceptance Criteria:**

- Occasion selection can alter page copy or form defaults.
- Occasion is stored with form/order.
- Occasion can be used for email segmentation later.

---

# Project 6 — Catering Lead Funnel

## Priority

P0 / P1

## Objective

Create a dedicated conversion path for office catering and event catering.

## Tasks

### Task 6.1 — Build catering landing page

**Recommended URL:** `/catering/twin-cities-office-lunch`

**Sections:** office lunch hero, popular packages, box lunches, sandwich platters, salads, bakery add-ons, dietary/allergen note, notice explanation, pickup locations, quote form, phone CTA, FAQ, testimonials/social proof.

**Acceptance Criteria:**

- Primary CTA: Get Catering Quote.
- Secondary CTA: Call Catering.
- Form captures UTMs.
- Catering submit event fires.
- Page has SEO title/meta description.
- Mobile sticky CTA included.

### Task 6.2 — Build catering form

**Fields:** name, email, phone, company, event date, event time, number of people, pickup location, catering type, budget range, dietary needs, message, hidden UTMs.

**Acceptance Criteria:**

- Required fields are validated.
- Event date cannot be in the past.
- Submission routes to internal team.
- Confirmation message sets expectations.
- Event fires on successful submit.

### Task 6.3 — Build catering package cards

**Cards:** box lunches, sandwich platters, salad spreads, breakfast meeting, bakery tray, team lunch bundle.

**Acceptance Criteria:**

- Cards are reusable.
- Each card can link to quote form with preselected interest.
- Works on mobile.

---

# Project 7 — Location SEO Pages

## Priority

P1

## Objective

Create high-converting local landing pages for each yum! location.

## Pages

- `/locations/st-louis-park`
- `/locations/shady-oak-minnetonka`
- `/locations/st-paul`
- `/locations/woodbury`

## Tasks

### Task 7.1 — Build location page template

**Sections:** location hero, hours, address, order online CTA, directions CTA, phone CTA, menu highlights, bakery highlights, catering CTA, cake pickup CTA, parking/location notes, Google Map embed, reviews/testimonials, FAQ, nearby neighborhoods served.

**Acceptance Criteria:**

- Each location has unique copy.
- Order links are location-specific.
- Directions links are location-specific.
- Phone numbers are location-specific.
- LocalBusiness/Restaurant schema added.
- CTA events include location name.

### Task 7.2 — Add location schema

**Schema Types:** Restaurant, Bakery if appropriate, LocalBusiness, BreadcrumbList.

**Acceptance Criteria:**

- Schema validates.
- Address, hours, phone, URL, geo coordinates included if available.
- No fake ratings unless verified.

### Task 7.3 — Add internal linking

**Acceptance Criteria:**

- Homepage links to all location pages.
- Location pages link to catering, Patticake, menu, and gift cards.
- Patticake local pickup page links back to locations.
- Footer includes location links.

---

# Project 8 — Patticake SEO / Occasion Pages

## Priority

P1

## Objective

Capture high-intent cake and gifting searches.

## Pages to Build

| Page | Goal |
|---|---|
| `/ship-birthday-cake` | Shipped birthday cake demand |
| `/send-a-cake` | General gifting demand |
| `/ship-thank-you-cake` | Gratitude/client gift demand |
| `/birthday-cake-pickup-minneapolis` | Local pickup demand |
| `/birthday-cake-pickup-st-paul` | Local pickup demand |
| `/corporate-gifting` | B2B gifting |
| `/wedding-cakes-twin-cities` | Wedding/event leads |

## Tasks

### Task 8.1 — Build occasion page template

**Sections:** occasion-specific hero, Patticake product explanation, pickup/shipping options, gift message explanation, CTA, FAQ, social proof, related occasions, corporate/wedding upsell where relevant.

**Acceptance Criteria:**

- Unique title/meta per page.
- Primary CTA uses correct event tracking.
- Form or checkout destination is clear.
- FAQ schema added where appropriate.
- Internal links connect related pages.

### Task 8.2 — Build birthday cake page

**CTA:** Order Birthday Patticake or Start Birthday Cake Request.

**Acceptance Criteria:**

- Birthday copy is distinct.
- Gift message field is emphasized.
- Reminder opt-in is offered.
- Birthday event fires correctly.

### Task 8.3 — Build thank-you cake page

**CTA:** Send a Thank-You Cake.

**Acceptance Criteria:**

- Good for friends, family, clients, team members.
- Corporate gifting CTA included.
- Multi-recipient inquiry link included.

---

# Project 9 — Corporate Gifting Funnel

## Priority

P1

## Objective

Turn Patticake into a higher-AOV B2B gifting product.

## Tasks

### Task 9.1 — Build corporate gifting landing page

**Recommended URL:** `/corporate-gifting`

**Sections:** hero, use cases, bulk order explanation, multi-address support, lead time, branded note option if available, quote form, FAQ, social proof.

**Acceptance Criteria:**

- Form captures company name and quantity.
- Quantity field supports bulk ranges.
- Corporate gifting submit event fires.
- Page links to Patticake product page.
- Page links to catering page for local office food.

### Task 9.2 — Build corporate gifting form

**Fields:** name, email, phone, company, quantity, desired send date, one address or multiple addresses, gift message needs, branding/customization needs, budget range, notes, hidden UTMs.

**Acceptance Criteria:**

- High-intent leads can be separated from small one-off buyers.
- Submissions route to sales/ops.
- Confirmation message promises follow-up.
- CRM/list tag: `corporate_gifting_lead`.

---

# Project 10 — Wedding / Event Cake Funnel

## Priority

P1

## Objective

Capture wedding, shower, and event cake demand.

## Tasks

### Task 10.1 — Build wedding cakes landing page

**Recommended URL:** `/wedding-cakes-twin-cities`

**Sections:** hero, Patticake wedding positioning, gallery, serving guide, event types, inquiry form, FAQ, vendor/venue notes, testimonials.

**Acceptance Criteria:**

- Form captures event date and guest count.
- Event date validation included.
- Page has wedding/event cake SEO title/meta.
- Wedding inquiry event fires.
- No unsupported delivery/setup claims.

### Task 10.2 — Build event inquiry form

**Fields:** name, email, phone, event type, event date, guest count, venue, pickup/delivery/setup question, desired cake style, message, hidden UTMs.

**Acceptance Criteria:**

- Lead is tagged as `wedding_event_lead`.
- Confirmation message explains next step.
- Internal team receives complete details.

---

# Project 11 — Gift Card Acquisition Page

## Priority

P1

## Objective

Turn gift cards into a seasonal acquisition and retention product.

## Task 11.1 — Build gift card landing page

**Sections:** hero, digital gift cards, physical gift cards if available, occasions, CTA, FAQ, cross-sell to Patticake, catering, and local order.

**Acceptance Criteria:**

- Gift card CTA is tracked.
- Page has gift-focused SEO metadata.
- Page links to Patticake and catering.
- Works as paid/social/email destination.

---

# Project 12 — Email / SMS Automation Setup

## Priority

P1

## Objective

Create owned-audience growth loops.

## Tasks

### Task 12.1 — Add email capture modules

**Locations:** homepage, location pages, catering page, Patticake pages, blog/content pages, order confirmation page if accessible.

**Offer examples:** seasonal menu drops, cake reminders, catering ideas, holiday gifting reminders.

**Acceptance Criteria:**

- Email submits are tracked.
- Source page is captured.
- UTM data is captured.
- User is tagged based on interest.

### Task 12.2 — Create segmentation taxonomy

| Tag | Meaning |
|---|---|
| restaurant_customer | Local food/order interest |
| catering_lead | Catering form submitter |
| cake_pickup_lead | Local cake interest |
| patticake_shipping_lead | Shipping interest |
| corporate_gifting_lead | Bulk gifting interest |
| wedding_event_lead | Wedding/event cake inquiry |
| gift_card_interest | Gift card CTA or signup |
| birthday_reminder | Birthday reminder opt-in |
| lapsed_customer | No recent purchase/order |
| high_value_customer | High spend or repeated orders |

### Task 12.3 — Build automation specs

**Deliverable:** `/docs/email-automation-spec.md`

**Automations:** welcome flow, second-order flow, catering nurture, cake reminder flow, gift buyer follow-up, lapsed customer winback, corporate gifting nurture, holiday gifting sequence.

---

# Project 13 — Review Capture System

## Priority

P1

## Objective

Increase review volume and keyword-rich local proof.

## Tasks

### Task 13.1 — Build review request landing page

**URL Example:** `/review`

**Sections:** thank-you message, location selector, Google review buttons by location, optional private feedback form, catering feedback path, cake feedback path.

**Acceptance Criteria:**

- User can select location.
- Correct Google review link opens.
- Private feedback form exists for issues.
- Review CTA clicks are tracked.

### Task 13.2 — Build QR code destinations

**Use cases:** pickup bags, catering boxes, cake boxes, table tents, receipts.

**Acceptance Criteria:**

- QR URL includes campaign/source tracking.
- Different QR campaigns exist: pickup_bag, catering_box, cake_box, in_store, receipt.

---

# Project 14 — Referral System

## Priority

P2

## Objective

Turn happy cake and catering customers into new customers.

## Tasks

### Task 14.1 — Build simple referral landing page

**Page:** `/refer`

**Referral Types:** Patticake gift referral, catering referral, local restaurant referral.

**Acceptance Criteria:**

- Users can enter email.
- Referral source is captured.
- Referral code or referral URL is generated if supported.
- At minimum, referral submissions route to CRM/list.

### Task 14.2 — Add post-purchase referral prompt

**Locations:** Patticake confirmation page, catering thank-you email, cake pickup follow-up email.

**Acceptance Criteria:**

- Referral CTA is tracked.
- Referral page includes UTMs.
- Referrer source is saved where possible.

---

# Project 15 — Paid Media Landing Page Pack

## Priority

P1

## Objective

Create dedicated pages for ad campaigns instead of sending paid traffic to generic pages.

## Landing Pages

| Page | Campaign |
|---|---|
| `/lp/office-lunch-catering` | Google + Meta catering ads |
| `/lp/send-birthday-cake` | Patticake birthday gifting |
| `/lp/local-birthday-cake-pickup` | Twin Cities cake pickup |
| `/lp/team-lunch` | Office/team catering |
| `/lp/holiday-gifting` | Seasonal gifting |
| `/lp/woodbury-takeout` | Location-specific local ads |
| `/lp/st-paul-bakery` | Location-specific bakery ads |

## Tasks

### Task 15.1 — Build paid landing page template

**Requirements:** reduced navigation, one primary CTA, fast load speed, mobile-first layout, tracking included, UTM capture included, social proof included, FAQ included, sticky CTA included.

**Acceptance Criteria:**

- Template supports different page content through config/CMS.
- All CTA clicks fire events.
- Page speed is acceptable.
- Works on mobile.

### Task 15.2 — Build first 3 paid pages

Start with office lunch catering, send birthday cake, and local birthday cake pickup.

---

# Project 16 — SEO Content System

## Priority

P2

## Objective

Create scalable SEO pages and articles around local food, catering, cake, and gifting intent.

## Tasks

### Task 16.1 — Build SEO content template

**Sections:** title, intro, content body, CTA block, FAQ, related pages, schema, author/date if blog-style.

**Acceptance Criteria:**

- Supports FAQ schema.
- Supports internal links.
- Supports CTA blocks.
- Easy for non-technical team to edit.

### Task 16.2 — Publish first 10 SEO pages/articles

**Topics:** office lunch catering, boxed lunch catering, birthday cake pickup, thank-you cake gifts, wedding cake alternatives, bakery gifts for clients, team lunch planning, local bakery gift ideas.

---

# Project 17 — Reporting Dashboard

## Priority

P1

## Objective

Give leadership one dashboard showing whether acquisition is working.

## Dashboard Sections

| Section | Metrics |
|---|---|
| Local orders | Order clicks, calls, directions, location page visits |
| Catering | Form submits, calls, qualified leads, booked orders |
| Patticake | Product page visits, request/order starts, submits, CAC |
| Paid media | Spend, CTR, CPC, CVR, CAC, ROAS |
| Email/SMS | List growth, sends, clicks, revenue/leads |
| SEO | Organic sessions, top landing pages, local page traffic |
| Reviews | Review count, average rating, review CTA clicks |

## Tasks

### Task 17.1 — Define dashboard schema

**Deliverable:** `/docs/dashboard-schema.md`

**Acceptance Criteria:**

- Every KPI has a source.
- Every KPI has a definition.
- Every KPI has an owner.
- Dashboard separates yum! and Patticake.

### Task 17.2 — Build dashboard

Can be Looker Studio, Google Sheets, Metabase, Airtable Interface, or internal admin page.

---

# Project 18 — CRO Testing System

## Priority

P2

## Objective

Continuously improve landing page conversion rate.

## Tasks

### Task 18.1 — Add A/B test-ready content slots

**Test areas:** hero headline, CTA copy, product image, form length, social proof placement, sticky CTA, offer framing.

**Acceptance Criteria:**

- Variant can be changed without code deploy if possible.
- Variant is captured in analytics.
- User experience remains stable.

### Task 18.2 — First CRO test plan

| Test | Hypothesis |
|---|---|
| Patticake CTA: Order vs Send | Send may convert better for gifting |
| Catering hero: Office lunch vs Team lunch | Office-specific language may improve B2B leads |
| Form length | Shorter form may increase lead volume |
| Social proof above fold | May increase cake conversion |
| Local pickup vs shipping first | Local users may convert better with pickup first |

---

# Project 19 — Creative Asset Library

## Priority

P1 / P2

## Objective

Organize photo/video assets so AI coders and marketers can build pages and ads quickly.

## Folder Structure

```text
/assets
  /yum
    /locations
      /st-louis-park
      /shady-oak
      /st-paul
      /woodbury
    /menu
    /bakery
    /catering
    /staff
  /patticake
    /product
    /slice
    /shipping
    /pickup
    /occasions
    /corporate-gifting
    /weddings
  /ads
    /meta
    /google
    /tiktok
  /ugc
  /logos
  /brand
```

## Task 19.1 — Build media library metadata file

**Deliverable:** `/assets/asset-index.json` or CMS equivalent.

**Fields:** file name, brand, category, location, occasion, usage rights, alt text, recommended page, recommended ad use.

---

# Project 20 — Admin / Internal Ops

## Priority

P2

## Objective

Make leads easy for the team to handle.

## Task 20.1 — Lead routing rules

| Lead Type | Route To |
|---|---|
| Catering | Catering/team email or CRM |
| Patticake pickup | Bakery/team email or CRM |
| Shipping request | Bakery/shipping ops |
| Corporate gifting | Sales/ops |
| Wedding/event | Event/cake lead handler |
| Private feedback | Manager/general inbox |

## Task 20.2 — Build lead status workflow

Statuses: New, Contacted, Waiting on customer, Quoted, Won, Lost, Follow-up later.

---

# Sprint Plan

## Sprint 0 — Setup and Audit

| Ticket | Priority |
|---|---|
| Crawl both sites | P0 |
| Create source-of-truth doc | P0 |
| URL decision map | P0 |
| Analytics event map | P0 |
| Asset inventory | P1 |

## Sprint 1 — Tracking and Conversion Base

| Ticket | Priority |
|---|---|
| Implement tracking helper | P0 |
| Add UTM capture utility | P0 |
| Build CTA wrapper | P0 |
| Build generic lead form | P0 |
| Build sticky mobile CTA | P0 |

## Sprint 2 — Patticake Fix

| Ticket | Priority |
|---|---|
| Fix Patticake product page | P0 |
| Remove placeholder review content | P0 |
| Clarify checkout vs request language | P0 |
| Build cake request/order form | P0 |
| Add occasion selector | P1 |

## Sprint 3 — Catering Funnel

| Ticket | Priority |
|---|---|
| Build catering landing page | P0 |
| Build catering form | P0 |
| Build catering package cards | P1 |
| Add catering tracking events | P0 |
| Add internal lead routing | P0 |

## Sprint 4 — Location SEO Pages

| Ticket | Priority |
|---|---|
| Build location template | P1 |
| Create four location pages | P1 |
| Add schema | P1 |
| Add internal linking | P1 |
| Add location-specific tracking | P1 |

## Sprint 5 — Patticake Growth Pages

| Ticket | Priority |
|---|---|
| Build occasion page template | P1 |
| Birthday cake page | P1 |
| Thank-you cake page | P1 |
| Local pickup cake pages | P1 |
| Corporate gifting page | P1 |
| Wedding cake page | P1 |

## Sprint 6 — Owned Audience + Reviews

| Ticket | Priority |
|---|---|
| Add email capture modules | P1 |
| Create segmentation taxonomy | P1 |
| Create email automation specs | P1 |
| Build review landing page | P1 |
| Build QR tracking destinations | P1 |

## Sprint 7 — Paid Landing Pages + Dashboard

| Ticket | Priority |
|---|---|
| Build paid landing page template | P1 |
| Build office lunch catering LP | P1 |
| Build birthday cake LP | P1 |
| Build local cake pickup LP | P1 |
| Define dashboard schema | P1 |
| Build dashboard | P1 |

---

# AI Coder Role Split

| AI Coder | Owns |
|---|---|
| Coder A — Architecture / Tracking | analytics event map, tracking helper, UTM capture, CTA tracking wrapper, dashboard schema, form data structure |
| Coder B — Frontend Components | hero, CTA blocks, lead forms, sticky CTA, location selector, card grids, FAQ, social proof |
| Coder C — Patticake Funnel | product page cleanup, cake form, occasion selector, birthday page, thank-you page, corporate gifting, wedding page |
| Coder D — yum! Local + Catering | catering landing page, catering form, location page template, four location pages, gift card page, local SEO schema |
| Coder E — QA / CRO / Performance | broken link checks, event testing, form testing, mobile QA, page speed checks, schema validation, CRO setup |

---

# Data Model

## Lead

| Field | Type |
|---|---|
| id | string |
| created_at | datetime |
| lead_type | enum |
| first_name | string |
| last_name | string |
| email | string |
| phone | string |
| company | string |
| event_date | date |
| occasion | enum |
| location_preference | enum |
| quantity | number |
| guest_count | number |
| message | text |
| utm_source | string |
| utm_medium | string |
| utm_campaign | string |
| utm_content | string |
| utm_term | string |
| landing_page | string |
| referrer | string |
| status | enum |
| owner | string |
| won_revenue | number |
| lost_reason | string |

## ConversionEvent

| Field | Type |
|---|---|
| event_name | string |
| timestamp | datetime |
| page_path | string |
| cta_label | string |
| brand | enum: yum, patticake |
| location | string |
| lead_type | string |
| campaign | string |
| session_id | string |

## Location

| Field | Type |
|---|---|
| slug | string |
| name | string |
| address | string |
| phone | string |
| hours | object |
| order_url | string |
| directions_url | string |
| menu_url | string |
| image | string |
| neighborhoods_served | array |

---

# Definition of Done for Every Page

A page is not done until it has:

- Clear primary CTA
- Clear secondary CTA where needed
- Mobile-optimized layout
- SEO title
- Meta description
- H1
- Internal links
- Image alt text
- Tracking on all primary CTAs
- UTM capture if form exists
- Form success state if form exists
- Error state if form exists
- No placeholder content
- No contradictory claims
- Schema where relevant
- Tested on desktop and mobile
- Broken links checked
