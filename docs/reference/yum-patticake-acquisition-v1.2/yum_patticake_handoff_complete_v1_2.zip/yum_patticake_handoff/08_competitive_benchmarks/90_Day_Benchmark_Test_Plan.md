# 90-Day Benchmark-Inspired Test Plan

The purpose is not to implement every competitor mechanic. It is to prove the smallest set that creates measurable demand for yum! and Patticake.

## Operating cadence

- **Monday:** performance review and this week's content board
- **Tuesday:** landing page / CRM / ops build
- **Wednesday:** catering and B2B outbound
- **Thursday:** Patticake gifting content
- **Friday:** bakery drop and weekend conversion
- **Monthly:** competitor refresh and experiment reprioritization

---

# Days 1–15 — Resolve conversion risk

## Work

1. Lock source-of-truth copy for pickup, shipping, celebration planning, and confirmation.
2. Redirect or rewrite the legacy yum cake page that says shipping/delivery is unavailable.
3. Verify analytics events for every order, call, directions, cake, and catering CTA.
4. Document Patticake shipping and fulfillment rules.
5. Establish baseline performance for:
   - Patticake order hub
   - shipping route
   - pickup route
   - catering page
   - four location pages
   - social-to-site traffic

## Benchmark used

- Milk Bar
- Baked by Melissa
- Portillo's
- Sweetgreen

## Launch gate

No paid gifting or catering traffic until the route, form, confirmation state, and tracking are coherent.

---

# Days 16–30 — Launch recurring content system

## Work

1. Launch `Fresh from yum!` weekly board.
2. Launch `The Message on Top` Patticake series.
3. Produce:
   - 8 vertical videos
   - 4 carousels
   - 20 Story frames
   - 8 Google Business Profile posts
4. Build one content capture day around:
   - bakery case
   - Patticake message writing
   - cake slice
   - catering pack-out
   - staff favorites
   - all four locations
5. Tag every asset by brand, location, occasion, funnel stage, and paid-use rights.

## Benchmark used

- Crumbl
- Cardigan Donuts
- Milk Bar

## Decision rule

Continue formats that beat account median on at least two of: hold rate, saves, shares, profile actions, site clicks, or order clicks.

---

# Days 31–45 — Occasion and local conversion pages

## Work

1. Launch Birthday Patticake page.
2. Launch Thank-You Patticake page.
3. Finalize Patticake shipping FAQ.
4. Rebuild one yum! location page as the model.
5. Add paid-landing-page template.
6. Start birthday reminder capture.

## Benchmark used

- Nothing Bundt Cakes
- Milk Bar
- Sweetgreen

## Decision rule

Compare route CTR, form start, form completion, and conversion rate against generic/current pages.

---

# Days 46–60 — B2B pilots

## Work

1. Launch corporate gifting page and qualified form.
2. Create multi-address spreadsheet template.
3. Recruit five Office Birthday Patticake pilot accounts.
4. Recruit five Monthly Office Lunch pilot accounts.
5. Deliver catering sample boxes to 25 targeted offices.
6. Establish response SLA and pipeline stages.

## Benchmark used

- Levain
- Tiff's Treats
- Baked by Melissa
- Tatte

## Decision rule

Do not automate the workflow until the manual pilot proves demand, margin, and repeat behavior.

---

# Days 61–75 — UGC, nostalgia, and packaging

## Work

1. Seed ten permissioned Patticake experiences.
2. Produce pack-out and unboxing assets.
3. Launch `Send a Twin Cities Favorite` test.
4. Add a tracked box insert for review, referral, and reminder actions.
5. Produce three real customer-story assets.

## Benchmark used

- Portillo's
- Levain
- Tiff's Treats

## Decision rule

Scale only creative that demonstrates both emotional engagement and downstream page action.

---

# Days 76–90 — Scale winners and kill noise

## Work

1. Analyze all experiments using a single dashboard.
2. Promote top organic creative into paid tests.
3. Retire weak templates and landing-page variants.
4. Decide whether to invest in:
   - referral software
   - e-gifting
   - automated multi-address workflows
   - premium packaging
   - expanded shipping acquisition
5. Refresh competitor swipe file.
6. Publish a next-quarter test plan.

## Final 90-day scorecard

| Workstream | Decision metric |
|---|---|
| Social cadence | Repeatable formats that generate order/page actions |
| Patticake CRO | Higher route and completion rates |
| Local pages | More orders, calls, and directions per visitor |
| Catering | Qualified leads, booked revenue, repeat rate |
| Corporate gifting | Qualified opportunities, AOV, close rate |
| Office programs | Enrolled accounts and second-order rate |
| Shipping | CAC, conversion, support burden, contribution margin |
| CRM | Dates captured, repeat orders, list growth |
| UGC | Approved asset yield and paid performance |

## Non-negotiable postmortem questions

- What created actual orders or qualified leads?
- What only generated vanity engagement?
- What promise caused operational strain?
- Which customer segment responded?
- Which creative can become a recurring format?
- Which build should be stopped rather than optimized?
