# Competitive Benchmark Playbook

**Brands:** yum! Kitchen & Bakery + Patticake  
**Verified:** July 10, 2026  
**Purpose:** Translate category-leading digital mechanics into a differentiated acquisition system.

---

# 1. Executive conclusion

The correct benchmark is not one restaurant or bakery. yum! and Patticake sit at the intersection of six commercial models:

1. Neighborhood restaurant frequency
2. Bakery drop culture
3. Celebration cake buying
4. Shipped food gifting
5. Office catering
6. Corporate and event gifting

The benchmark system therefore combines:

```text
Crumbl's recurring release cadence
+ Milk Bar's birthday/shipping clarity
+ Nothing Bundt Cakes' occasion merchandising
+ Levain's gift operations and packaging
+ Tiff's Treats' recurring corporate programs
+ Portillo's regional nostalgia
+ Sweetgreen's local conversion UX
+ Magnolia's hero-product architecture
```

This is the practical target:

- **yum!** becomes easier to discover, order, revisit, and use for office food.
- **Patticake** becomes easier to understand, personalize, pick up, ship, gift, and reorder.

---

# 2. What each benchmark solves

| Job to be done | Strong benchmark | Proven mechanic | yum!/Patticake adaptation |
|---|---|---|---|
| Create recurring anticipation | Crumbl | Dated weekly flavor drop, limited availability, repeat reveal ritual | Weekly “Fresh from yum!” bakery-case drop and seasonal Patticake reveal |
| Make one cake iconic | Milk Bar | Birthday product treated as a branded destination | Patticake becomes a named gift, not a generic custom-cake inquiry |
| Sell by occasion | Nothing Bundt Cakes | Birthday, thank-you, wedding, corporate, holiday, just-because navigation | Patticake occasion hub and occasion-specific landing pages |
| Make gifting operationally easy | Levain Bakery | Multi-address, e-gift, personal note, gift packaging, bulk support | Patticake single-recipient checkout/request plus bulk gifting concierge |
| Productize recurring business gifting | Tiff's Treats | Birthday/anniversary programs, corporate billing, packaging, concierge | Office Birthday Patticake Program and Client Thank-You Program |
| Turn local identity into national demand | Portillo's | Regional food nostalgia plus nationwide shipping | “Send a Twin Cities favorite” Patticake campaign |
| Convert local search traffic | Sweetgreen | Transactional location pages with ordering, hours, rewards, and catering | Every yum! location page becomes an order/directions/catering/cake hub |
| Extend one hero into multiple channels | Magnolia Bakery | Hero dessert supports local pickup, shipping, events, and corporate gifting | Patticake supports pickup, shipping, office gifting, weddings, and seasonal campaigns |
| Reduce fulfillment anxiety | Baked by Melissa | Explicit shipping transit, packaging, service areas, and B2B options | Patticake shipping FAQ with dates, packaging, restrictions, and confirmation steps |
| Sell hospitality visually | Maman / Tatte | Distinctive environment, table spreads, office catering, human warmth | yum! keeps real neighborhood hospitality while improving visual discipline |
| Build local limited-release behavior | Cardigan Donuts | Pickup/delivery plus product-driven local content | Bakery-case drops tied to each yum! location and available quantities |

---

# 3. Brand deep dives

## 3.1 Crumbl — recurring demand engine

### Observed mechanics

- The homepage is organized around a dated weekly menu.
- New and returning flavors are framed as time-limited.
- The rewards program connects status, birthday benefits, flavor voting, exclusive offers, and a Sunday pre-order window.
- Product novelty supplies a continuous stream of reveal, ranking, reaction, and review content.

### Why it works

The brand does not have to invent a new social strategy every week. The **release calendar is the content strategy**.

### Adapt for yum!

Do not rotate the entire menu. Create a lower-operational-risk ritual:

- **Monday:** “Fresh from yum!” weekly bakery board
- **Thursday:** weekend case preview
- **Friday:** limited bakery drop or seasonal item
- **Sunday:** next-week teaser and order-ahead reminder

The weekly board can feature existing items, seasonal availability, staff picks, or one limited component. The content cadence can be consistent even when the underlying products are not radically new.

### Adapt for Patticake

- “Message of the Week” content series
- Seasonal Patticake styling or gift-note insert
- Birthday reminder opt-in
- Early-access email/SMS for limited seasonal variations

### Do not copy

- High SKU churn
- Constant novelty without operational capacity
- Trend chasing that weakens Patticake's signature-product equity

---

## 3.2 Milk Bar — iconic birthday gifting

### Observed mechanics

- Birthday Cake has its own high-intent product destination.
- Nationwide shipping is explicit.
- Product, shipping, storage, destination, and gifting questions are handled near the decision point.
- Corporate gifting is presented as customizable and supports recipient-address submission.
- The brand groups products by occasion such as birthdays, thank-yous, and congratulations.

### Why it works

The customer is not buying “a cake.” The customer is solving a specific social obligation: remember a birthday, send thanks, celebrate, or show up from far away.

### Adapt for Patticake

Build this routing structure:

```text
Order a Patticake
├── Pick Up Locally
├── Ship a Patticake
├── Birthday
├── Thank You
├── Office Celebration
├── Corporate Gifting
└── Wedding / Event
```

Every branch should answer:

- How it works
- What can be personalized
- Available date expectations
- Pickup or shipping rules
- What happens after submission/payment
- Who to contact for help

### Do not copy

- Overly irreverent language that does not fit yum!
- A highly polished national-DTC tone that erases Twin Cities hospitality

---

## 3.3 Nothing Bundt Cakes — occasion merchandising

### Observed mechanics

- Navigation is organized around life occasions, not just cake types.
- Corporate gifting includes repeat employee birthday/celebration use cases.
- Add-ons and message cards help complete the occasion.
- Local bakery execution and availability are integrated into the journey.
- Loyalty includes birthday benefits and bonus-point opportunities.

### Why it works

Occasion framing reduces the buyer's planning burden. It tells customers, “This product is already designed for the moment you are trying to handle.”

### Adapt for Patticake

Create named occasion modules:

- Birthday Patticake
- Thank-You Patticake
- Congratulations Patticake
- Office Birthday Patticake
- Client Gift Patticake
- Wedding / Shower Patticake
- Just-Because Patticake

Each uses the same core cake while changing:

- Headline
- message examples
- photography context
- CTA
- reminder option
- related add-ons

### Do not copy

- Franchise-style generic celebration visuals
- Excessive decoration options that slow production

---

## 3.4 Levain Bakery — premium gifting operations

### Observed mechanics

- The corporate page separates self-service gifting from bespoke support.
- Customers can upload address lists, send e-gifts, include individual notes, and ship to multiple recipients.
- Packaging, customization, bulk discounts, lead times, and a gifting specialist are explicit.
- The broader commerce system includes referrals and subscription behavior.

### Why it works

Levain treats gift logistics as part of the product. The buyer is purchasing both food and administrative relief.

### Adapt for Patticake

### Gift Ops 1.0

- One recipient
- desired arrival/pickup date
- gift message
- occasion
- confirmation workflow

### Gift Ops 2.0

- corporate inquiry form
- quantity tiers
- multi-address spreadsheet upload
- branded note option
- defined lead time
- dedicated owner
- bulk pricing rules

### Gift Ops 3.0

- recipient-choice e-gift
- automated birthday reminders
- saved recipient list
- annual corporate program

### Do not copy

- Expensive custom packaging before unit economics are proven
- Complex e-gifting software before there is demonstrated demand

---

## 3.5 Tiff's Treats — recurring corporate programs

### Observed mechanics

- Same-day/on-demand delivery creates urgency where operationally possible.
- Corporate gifting is organized around employee and client use cases.
- Birthday/anniversary gifting is a named program.
- Concierge help, corporate billing, volume discounts, and custom packaging reduce B2B friction.
- Catering is productized by party size and product format.

### Why it works

The company does not wait for random corporate orders. It turns repeat office needs into programs.

### Adapt for yum! and Patticake

- **Monthly Office Lunch Program**
- **Office Birthday Patticake Program**
- **Client Thank-You Patticake Program**
- **New Hire / Promotion Celebration Program**
- **Holiday Multi-Recipient Gifting Program**

Start manually. A dedicated spreadsheet, owner, reminder schedule, and invoice process are enough for the pilot.

### Do not copy

- Same-day promises unless operations can consistently fulfill them
- Custom packaging minimums before demand is validated

---

## 3.6 Portillo's — regional nostalgia to nationwide shipping

### Observed mechanics

- Local takeout/delivery, catering, and nationwide shipping are clearly separated.
- The famous chocolate cake is an identifiable shipped product.
- Shipping copy turns Chicago identity into an emotional gift.

### Why it works

Regional affinity is a purchase trigger. Customers are not only buying food; they are sending a place, a memory, and an identity.

### Adapt for Patticake

Campaign territory:

- “Send a Twin Cities favorite.”
- “For the person who moved away but still talks about yum!.”
- “Send the cake they remember.”
- “A little Twin Cities love, delivered.”

Audience tests:

- Former Minnesota residents
- Parents sending to adult children
- Alumni communities
- corporate contacts with Minnesota ties
- customers who purchased locally and later moved

### Do not copy

- Force nostalgia into every message
- Claim national fame that has not been earned

---

## 3.7 Sweetgreen — local conversion UX

### Observed mechanics

- Location pages expose address, hours, directions, phone, ordering, rewards, and catering.
- Rewards are tied to first-party orders and repeat behavior.
- Catering availability is visible at the local level.

### Why it works

The page resolves the customer's immediate local questions and gives multiple measurable conversion paths.

### Adapt for yum!

Every location page should include:

1. Order online
2. Get directions
3. Call
4. hours and holiday note
5. parking guidance
6. current menu highlights
7. bakery case module
8. catering CTA
9. Patticake pickup CTA
10. email/SMS signup
11. local reviews
12. nearby neighborhoods served

### Do not copy

- Sterile app-first language
- A technology-company aesthetic that weakens yum!'s hospitality

---

## 3.8 Magnolia Bakery — hero-product architecture

### Observed mechanics

- Recognizable hero desserts anchor the brand.
- Fulfillment choices are clearly separated: nationwide shipping, local pickup, catering, gifting, and events.
- Corporate and celebration inquiries have dedicated pathways.

### Why it works

A hero product acts as a commercial platform. It can drive direct sales, content, PR, gifting, events, and partnerships.

### Adapt for Patticake

Treat Patticake as a platform with these offers:

- whole cake local pickup
- shipped cake
- office birthday cake
- wedding/event format
- corporate thank-you gift
- seasonal collaboration
- slice content and in-store sampling

### Do not copy

- Unsupported superlatives
- Too many disconnected dessert sub-brands

---

## 3.9 Baked by Melissa — fulfillment clarity

### Observed mechanics

- Nationwide shipping parameters are specific.
- Packaging and transit are described.
- Corporate buyers can use self-service multi-address ordering or a concierge path.
- The brand distinguishes routine ecommerce from customized B2B service.

### Why it works

Shipping uncertainty destroys conversion. Concrete fulfillment answers make a food gift feel safe enough to buy.

### Adapt for Patticake

The shipping page and FAQ should answer:

- Where can Patticake ship?
- Which days are available?
- How far ahead should customers order?
- How is the cake packed?
- What should the recipient do on arrival?
- Can a buyer select an arrival date?
- What happens during extreme heat or weather?
- Can one order go to multiple addresses?
- Is the request confirmed immediately or by the bakery team?
- What happens if an address is wrong or a carrier is delayed?

### Do not copy

- Specific transit or packaging claims until operations confirms them

---

## 3.10 Maman and Tatte — hospitality presentation

### Observed mechanics

- Food and environment are presented as one cohesive visual world.
- Catering is framed for home, office, meetings, celebrations, and full-service events.
- Ordering logistics and service minimums are communicated without making the brand feel transactional.

### Why it works

The visual system raises perceived value while the operational copy lowers anxiety.

### Adapt for yum!

Use real Twin Cities hospitality rather than mimicking a French café:

- natural table spreads
- recognizable stores and neighborhoods
- hands serving food
- staff voices
- meeting-ready catering arrangements
- real packaging
- warm food close-ups
- simple typography and restrained overlays

### Do not copy

- Aesthetic cosplay
- Over-styled content that no longer feels like yum!

---

## 3.11 Cardigan Donuts — local benchmark

### Observed mechanics

- The site exposes pickup, delivery, gift cards, catering, and weddings/events.
- Product-led visuals create local discovery and sharing.
- The brand gives Twin Cities customers multiple reasons to transact beyond a walk-in visit.

### Adapt for yum!

- Treat each bakery case as a local content source.
- Make the location explicit in every drop post.
- Use “available today at…” and “order/pick up from…” language.
- Build creator seeding around specific locations, not one undifferentiated metro audience.

---

# 4. The differentiated yum! + Patticake model

## yum! acquisition loop

```text
Local search / social discovery
→ location page
→ order, directions, call, or catering
→ first-party email/SMS capture
→ second visit
→ catering, gift card, or Patticake cross-sell
```

## Patticake acquisition loop

```text
Occasion trigger / social proof / search
→ occasion page
→ pickup or shipping route
→ message and date
→ purchase/request confirmation
→ delivery/pickup experience
→ recipient/referrer capture
→ birthday or occasion reminder
→ repeat gifting
```

## B2B loop

```text
Office lunch or gifting need
→ dedicated page
→ clear package/program
→ qualified form
→ assigned owner
→ quote/order
→ post-order feedback
→ recurring schedule
```

---

# 5. Creative systems to launch

## Series 1 — Fresh from yum!

**Format:** Weekly Reel, carousel, Story, GBP post  
**Content:** Three bakery/menu items available this week  
**CTA:** Order or visit selected location  
**Mechanic borrowed:** Crumbl release cadence  
**Differentiation:** Real scratch-kitchen and neighborhood context

## Series 2 — The Message on Top

**Format:** Vertical video and static close-up  
**Content:** Writing a real Patticake message  
**CTA:** Start a cake request/order  
**Mechanic borrowed:** Occasion merchandising  
**Differentiation:** Personal words are the hero

## Series 3 — Send a Twin Cities Favorite

**Format:** UGC, unboxing, founder/customer story, paid social  
**Content:** Long-distance recipient and Minnesota connection  
**CTA:** Ship a Patticake  
**Mechanic borrowed:** Portillo's regional nostalgia  
**Differentiation:** Patticake's local history and customer stories

## Series 4 — Office Lunch That Gets Eaten

**Format:** Catering spread, assembly, office reaction  
**Content:** Box lunches, platters, salads, bakery add-ons  
**CTA:** Get a catering quote  
**Mechanic borrowed:** Tiff's/Tatte catering productization

## Series 5 — What We Would Order

**Format:** Staff-led Reel  
**Content:** One staff member's exact yum! order  
**CTA:** Order from nearest location  
**Mechanic borrowed:** Creator-style recommendation  
**Differentiation:** Real employees and specific combinations

## Series 6 — Patticake Arrives

**Format:** Shipping pack-out and recipient unboxing  
**Content:** Packaging, arrival, storage/serving steps  
**CTA:** Send a cake  
**Mechanic borrowed:** Levain/Baked by Melissa gifting clarity

---

# 6. Product and program concepts

| Concept | Minimum viable version | Later version | Primary KPI |
|---|---|---|---|
| Weekly bakery board | One post and Story per week | Email/SMS early access and location inventory | Reach-to-order clicks |
| Birthday Patticake | Dedicated page and message examples | Birthday reminder and saved recipients | Cake conversion rate |
| Office Birthday Program | Manual recurring calendar and invoicing | Portal / recipient management | Recurring B2B revenue |
| Corporate gifting | Qualified form and spreadsheet upload | Self-service multi-address/e-gift | Qualified leads and AOV |
| Send Minnesota campaign | One landing page and 3 ads | Alumni/relocation partnerships | Shipping CAC |
| Catering sample box | Manually fulfilled local prospect offer | Automated outbound + CRM sequence | Lead-to-order rate |
| Referral insert | QR card in cake box | Give/get credit system | Referral conversions |
| Gift reminder | Email opt-in and tagged date | Automated annual reminder | Repeat cake orders |
| Review capture | QR by location and order type | Automated post-order workflow | Review volume and rating |

---

# 7. What not to copy

| Failure mode | Why it is wrong for yum!/Patticake |
|---|---|
| Constant product churn | Creates operational burden and dilutes signature products |
| Generic national bakery voice | Erases local credibility and founder/customer history |
| Expensive packaging before margin validation | Converts a marketing idea into a cash-flow problem |
| “Same day” promises without capacity | Acquires customers by creating service failures |
| Dozens of customization options | Increases errors, labor, and abandoned forms |
| Sending all traffic to a homepage | Hides the next step and weakens measurement |
| Building a custom app too early | Solves the wrong problem before basic first-party ordering and CRM work |
| Copying visual aesthetics literally | Creates imitation rather than a recognizable yum! system |
| Using fake or placeholder reviews | Destroys trust |
| Mixing checkout and inquiry language | Makes customers unsure whether they placed an order |

---

# 8. Competitive scorecard

Score each future benchmark from 1–5.

| Dimension | Question |
|---|---|
| Hero clarity | Is the signature product obvious within five seconds? |
| Occasion clarity | Can buyers shop by the moment they need to solve? |
| Fulfillment clarity | Are pickup, local delivery, shipping, and timing explicit? |
| Local conversion | Are order, directions, phone, hours, and catering easy to find? |
| Gift operations | Are messages, recipients, multi-address, and support handled? |
| B2B productization | Is there a defined program, minimum, lead time, and owner? |
| Social repeatability | Does the brand have recurring formats rather than random posts? |
| First-party retention | Are rewards, email, SMS, referral, or reminders integrated? |
| Visual distinctiveness | Could the creative be recognized without the logo? |
| Operational realism | Can the promises be delivered consistently? |

---

# 9. Immediate build implications

## P0

1. Remove the legacy yumkitchen.com cake-page contradiction that says shipping is unavailable while Patticake offers a shipping route.
2. Finalize one source of truth for order, request, pickup, shipping, and confirmation language.
3. Track pickup, shipping, celebration, catering, call, directions, and order CTAs.
4. Build or finalize the Patticake shipping FAQ.
5. Make all four yum! location pages transactional.

## P1

6. Launch the birthday, thank-you, corporate gifting, and office celebration Patticake pages.
7. Launch the catering landing page and sample-box test.
8. Start the weekly “Fresh from yum!” content ritual.
9. Create the Office Birthday Patticake pilot.
10. Add birthday/reminder and referral capture.

## P2

11. Add multi-address spreadsheet upload.
12. Test branded notes and packaging tiers.
13. Launch “Send a Twin Cities Favorite.”
14. Build creator seeding around each location.
15. Add automated annual occasion reminders.

---

# 10. Source discipline

The examples in this module were checked against official brand sites and public official social profiles on July 10, 2026. Digital experiences change. Re-run the competitive research agent monthly and confirm any operational claim before adapting it.

See `Live_Example_Links.csv` for the working reference set.
