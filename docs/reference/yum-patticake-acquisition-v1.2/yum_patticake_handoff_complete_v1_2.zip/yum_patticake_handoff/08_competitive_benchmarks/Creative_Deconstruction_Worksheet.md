# Creative Deconstruction Worksheet

Use one worksheet per social post, ad, landing page, email, SMS, offer, packaging system, or physical insert.

## 1. Reference

- **Capture ID:**
- **Date reviewed:**
- **Brand:**
- **Channel / format:**
- **Official URL:**
- **Campaign or recurring series:**
- **Observed fact vs inference:**

## 2. Commercial job

- What customer problem is this asset solving?
- What business result is it designed to produce?
- What funnel stage does it serve?
- Is the primary action obvious within three seconds?

## 3. Hook

- First visual:
- First words / headline:
- Curiosity, urgency, utility, identity, proof, or emotion used:
- Why would the intended customer stop?

## 4. Offer and CTA

- Product or program offered:
- Price / threshold / deadline, if shown:
- Primary CTA:
- Secondary CTA:
- Destination:
- Does the destination match the promise?

## 5. Visual system

- Product framing:
- Human presence:
- Packaging:
- Environment:
- Camera movement / edit pattern:
- Typography / overlays:
- Recognizable brand device:
- Could the asset be recognized without its logo?

## 6. Proof

- Review or testimonial:
- Product process:
- Customer reaction:
- Quantity / scale:
- Client logos:
- Scarcity / availability:
- Operational detail:

## 7. Repeatability

- Is this a one-off or a reusable series?
- What inputs are required each week/month?
- Can the team produce it without an agency?
- Can it be reused organically and as paid creative?

## 8. Operational reality

- What promise must operations deliver?
- What data must be accurate?
- What could create customer-service failure?
- What approval is required?

## 9. Adaptation

### yum! version

- Hook:
- Visual:
- Offer:
- CTA:
- Location or menu input:
- KPI:

### Patticake version

- Hook:
- Visual:
- Occasion:
- Pickup/shipping route:
- CTA:
- KPI:

## 10. Anti-copy rule

Write the element that must **not** be copied literally—tone, palette, phrase, packaging, product complexity, offer, or operational promise.

## 11. Decision

- [ ] Add to production backlog
- [ ] Run as paid creative test
- [ ] Use only as strategic reference
- [ ] Archive
- [ ] Revisit later

**Owner:**  
**Due date:**  
**Related experiment ID:**
