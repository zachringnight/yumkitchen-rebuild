# Social Content Archetypes from the Benchmark Set

Use these as repeatable production briefs. Each asset needs a destination and tracked CTA.

| # | Archetype | Benchmark mechanic | yum!/Patticake execution | Primary CTA |
|---:|---|---|---|---|
| 1 | Weekly reveal | Crumbl | Three items fresh from yum! this week | Order / visit location |
| 2 | Limited availability | Crumbl | Weekend bakery case while quantities last | Order / directions |
| 3 | Ranking/review | Crumbl creator ecosystem | Staff or creator ranks three bakery items | Order |
| 4 | Iconic product cut | Milk Bar | First Patticake slice and interior layers | Order a Patticake |
| 5 | Pack with us | Milk Bar / Levain | Prepare a pickup or shipping cake | Ship / pick up |
| 6 | Occasion message | Nothing Bundt Cakes | Write birthday, thanks, congrats, or office message | Start cake order |
| 7 | Gift completion | Levain | Box, card, note, ribbon/insert, handoff | Send a cake |
| 8 | Multi-recipient proof | Levain | “X cakes headed to one client team” | Corporate inquiry |
| 9 | Office program | Tiff's Treats | Monthly birthdays handled by Patticake | Enroll company |
| 10 | Catering by group size | Tiff's Treats | What to order for 10, 20, or 40 people | Get a quote |
| 11 | Regional nostalgia | Portillo's | Send a Twin Cities favorite to someone who moved | Ship a cake |
| 12 | Location utility | Sweetgreen | Exact order, parking, hours, and pickup flow at one yum! | Order / directions |
| 13 | Hero product history | Magnolia | Why Patticake became the cake people ask for | Learn / order |
| 14 | Arrival confidence | Baked by Melissa | What arrives, what to do, and how to serve | Ship a cake |
| 15 | Table spread | Maman / Tatte | Office breakfast/lunch with bakery add-ons | Catering quote |
| 16 | Staff exact order | Creator-native | Employee's full yum! order and why | Order location |
| 17 | Customer tradition | Regional/iconic brands | Family birthday or office tradition involving Patticake | Order / save date |
| 18 | Review visualization | DTC gifting brands | Real verified review paired with cake/food process | Order |
| 19 | Seasonal deadline | All gifting leaders | Order-by date and fulfillment route | Order now |
| 20 | Recipient reaction | Gifting brands | Permissioned unboxing/reaction | Send one |

## Production rule

For every archetype, export:

- 9:16 master
- 1:1 or 4:5 feed cut
- three hook variants
- one no-audio-readable version
- one paid-safe version without copyrighted music
- caption with tracked destination
- source and usage-rights record
