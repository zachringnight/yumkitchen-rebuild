# Competitive Benchmark Executive Summary

**Research date:** July 10, 2026

## What the category leaders prove

The strongest food brands do not rely on one generic website, one social feed, or one “order now” message. They build different acquisition systems around different customer jobs.

| Customer job | Leading mechanic | yum!/Patticake move |
|---|---|---|
| “Give me a reason to check back” | Crumbl's recurring drop | Weekly Fresh from yum! board |
| “Help me send a birthday cake” | Milk Bar's birthday-first funnel | Birthday Patticake page and shipping FAQ |
| “Help me choose for this occasion” | Nothing Bundt Cakes' occasion structure | Birthday, thank-you, office, wedding, just-because routes |
| “Handle a long recipient list” | Levain's gift operations | Multi-address spreadsheet and dedicated gifting owner |
| “Handle birthdays all year” | Tiff's Treats' corporate programs | Office Birthday Patticake pilot |
| “Send them something from home” | Portillo's regional nostalgia | Send a Twin Cities Favorite campaign |
| “Show me the nearest place and what to do” | Sweetgreen's location UX | Transactional pages for all four yum! locations |
| “Make this iconic product useful everywhere” | Magnolia's hero-product architecture | Patticake across pickup, shipping, corporate, and events |

## Highest-priority decisions

1. **Fix the domain contradiction.** The legacy yum cake page still says shipping/delivery is unavailable while Patticake offers a shipping route.
2. **Make fulfillment explicit.** Every Patticake page must distinguish pickup, shipping, celebration planning, request, payment, and confirmation.
3. **Make the location pages transactional.** Order, directions, phone, parking, catering, bakery, and Patticake pickup must be visible and tracked.
4. **Launch recurring formats.** The content team needs repeatable series, not a new brainstorm every day.
5. **Pilot B2B manually.** Prove Office Birthday Patticake and Monthly Office Lunch programs before buying software.

## First six benchmark-informed builds

| Order | Build | Owner | KPI |
|---:|---|---|---|
| 1 | Patticake shipping FAQ and source-of-truth cleanup | Ops + Web | Form completion; fewer support questions |
| 2 | Birthday Patticake landing page | Web + Growth | Cake conversion rate |
| 3 | Fresh from yum! weekly content board | Social + Store Ops | Social-to-order actions |
| 4 | Model yum! location conversion page | Web + Local SEO | Order, call, and directions actions |
| 5 | Corporate gifting page and qualified form | Web + Sales | Qualified leads and AOV |
| 6 | Office Birthday Patticake pilot | Sales + Ops | Enrolled accounts and second-order rate |

## Strategic boundary

Do not copy the brands' aesthetics or voice. Use the mechanics only. Any tactic must meet four conditions:

- Fits yum!/Patticake's actual customer
- Can be fulfilled consistently
- Has a measurable destination
- Can be stopped quickly if it does not produce orders, qualified leads, or retention
