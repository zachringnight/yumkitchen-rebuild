# Competitive Benchmarks + Swipe-File Module

**Research date:** July 10, 2026

This module converts strong restaurant, bakery, gifting, catering, and direct-to-consumer examples into executable work for **yum! Kitchen & Bakery** and **Patticake**.

It is not a mood board. It is a decision and testing system.

## Start here

1. Read `Competitive_Benchmark_Playbook.md`.
2. Review `Brand_Benchmark_Matrix.csv` to understand which brand to study for each job.
3. Use `Live_Example_Links.csv` to inspect current official examples.
4. Import `Benchmark_Inspired_Experiment_Backlog.csv` into the project-management system.
5. Use `Creative_Deconstruction_Worksheet.md` whenever a page, ad, post, email, or packaging idea enters the swipe file.
6. Give `AI_Competitive_Research_Agent_Prompt.txt` to a web-enabled research agent once per month.
7. Run the first 90 days from `90_Day_Benchmark_Test_Plan.md`.

## Benchmark stack

| Need | Primary benchmark |
|---|---|
| Recurring social demand | Crumbl |
| Birthday cake and nationwide gifting | Milk Bar |
| Occasion-based merchandising | Nothing Bundt Cakes |
| Premium packaging and multi-recipient gifting | Levain Bakery |
| Corporate birthday/anniversary programs | Tiff's Treats |
| Regional nostalgia converted to shipping | Portillo's |
| Local pages, ordering, loyalty, and catering | Sweetgreen |
| Hero-product brand architecture | Magnolia Bakery |
| Shipping FAQ and B2B fulfillment clarity | Baked by Melissa |
| Hospitality aesthetic and catering presentation | Maman / Tatte |
| Twin Cities-local drop behavior | Cardigan Donuts |

## Operating rule

Copy the **mechanic**, not the costume.

- Do not make yum! look like Crumbl.
- Do not make Patticake sound like Milk Bar.
- Do use proven mechanics: recurring drops, occasion pages, routing clarity, gift messages, address workflows, location conversion pages, referral loops, and office programs.

## Additional client-ready files

- `Competitive_Benchmark_Executive_Summary.md`
- `Benchmark_To_Execution_Examples.md`
