# Benchmark-to-Execution Examples

These are practical translations—not copy. Final language and operational claims require brand and ops approval.

---

# Example 1 — Crumbl weekly reveal → Fresh from yum!

## Reference mechanic

A dated recurring product reveal creates anticipation and gives customers a reason to return.

## yum! asset

**15-second Reel**

```text
0:00–0:02  Open bakery case / text: “Fresh from yum! this week”
0:02–0:06  Item 1 close-up + name
0:06–0:10  Item 2 cut / spoon / pull
0:10–0:13  Item 3 tray entering case
0:13–0:15  “Available at [location]. Order or stop in.”
```

**Caption direction:**

> Three reasons to make a yum! stop this week: [ITEM], [ITEM], and [ITEM]. Availability varies by location and quantities. Check your nearest yum! before they are gone.

**CTA:** Order from or get directions to the featured location.  
**Tracking:** `utm_campaign=fresh_from_yum_[week]`

---

# Example 2 — Milk Bar birthday funnel → Birthday Patticake

## Reference mechanic

A birthday-specific product page answers the occasion, fulfillment, and gifting questions in one place.

## Patticake above-the-fold draft

**Headline:**

> Send the birthday cake they will remember.

**Subhead:**

> Choose local pickup or shipping, add the message for the top, and tell us when the celebration happens.

**Primary CTA:** Start a Birthday Patticake  
**Secondary CTA:** See pickup and shipping details

**Required proof modules:**

- cake interior and serving view
- verified customer quote
- pickup/shipping route
- what happens after the request/order
- birthday-message examples
- timing FAQ

---

# Example 3 — Nothing Bundt Cakes occasion merchandising → Patticake Moments

## Reference mechanic

Customers shop the social moment, not a generic cake category.

## Occasion card set

| Card | Headline | Message examples | CTA |
|---|---|---|---|
| Birthday | The birthday cake part is handled. | Happy 40th; Best Day Ever; Make a Wish | Start Birthday Cake |
| Thank You | Say thanks in chocolate and buttercream. | Thank You; You Saved Us; We Appreciate You | Send Thanks |
| Congratulations | Make the win taste better. | You Did It; Congrats; So Proud | Celebrate Them |
| Office | Handle the office birthday without another email chain. | Happy Birthday [Name]; Go Team; Big Win | Plan an Office Cake |
| Just Because | No calendar event required. | Miss You; Love You; Tuesday! | Send a Patticake |

---

# Example 4 — Levain gifting operations → Patticake corporate intake

## Reference mechanic

Large gift orders need administrative relief: addresses, notes, timing, customization, and a real owner.

## Corporate form structure

```text
Contact name
Company
Email / phone
Quantity range
One address or multiple addresses
Desired delivery/pickup dates
Recipient geography
Gift-message requirements
Branding/custom note requirements
Budget range
Spreadsheet upload
Notes
```

## Success state

> Request received. A Patticake gifting lead will review availability, timing, addresses, and final pricing before your order is confirmed.

## Internal SLA

- Assign owner immediately
- First response within one business day
- Validate service area and dates before quoting
- Store original UTM and campaign source

---

# Example 5 — Tiff's Treats recurring program → Office Birthday Patticake

## Reference mechanic

Turn a recurring office obligation into a named program.

## Pilot offer

**Headline:**

> We will remember the office birthdays. You take the credit.

**MVP workflow:**

1. Company submits the next 90 days of birthdays.
2. yum! confirms preferred location, size, messages, billing, and lead time.
3. Program owner sends a reminder before each birthday.
4. Company confirms or changes the order.
5. After three orders, review for recurring monthly billing.

**Pilot limit:** Five companies.  
**Primary KPI:** Second-order rate.  
**Do not build yet:** Self-service portal.

---

# Example 6 — Portillo's regional nostalgia → Send a Twin Cities Favorite

## Reference mechanic

A shipped food product can represent a place and a memory.

## Paid social concepts

### Concept A — Moved away

**Hook:**

> They moved away. Their Patticake opinion did not.

**Visual:** Twin Cities sender → cake pack-out → recipient reaction.  
**CTA:** Ship a Patticake.

### Concept B — Parent to adult child

**Hook:**

> A little Twin Cities birthday delivery.

**Visual:** Message-writing close-up; address label; door arrival.  
**CTA:** Send their birthday cake.

### Concept C — Former customer story

**Hook:**

> The cake they still talk about, even from [CITY].

**Visual:** Real customer quote and unboxing.  
**CTA:** Send a Twin Cities favorite.

---

# Example 7 — Sweetgreen location UX → yum! location page

## Reference mechanic

The local page resolves immediate questions and offers multiple measurable actions.

## Mobile page order

```text
Location name + neighborhood
Open/closed status and today's hours
Order Online
Get Directions
Call
Parking note
Top menu items
Bakery this week
Catering from this location
Pick up a Patticake
Verified reviews
Nearby neighborhoods
Email/SMS signup
FAQ
```

## Sticky mobile bar

- Primary: Order
- Secondary: Directions

## Event parameters

```text
brand=yum
location=st_louis_park | shady_oak | st_paul | woodbury
page_type=location
cta_label=[label]
```

---

# Example 8 — Magnolia hero product → Patticake platform

## Reference mechanic

One recognized dessert is extended into multiple revenue lanes.

## Patticake navigation module

```text
Patticake
├── Order a Patticake
├── Pick Up Locally
├── Ship a Patticake
├── Birthdays
├── Corporate Gifting
├── Weddings & Events
└── Patticake Story
```

## Homepage block

**Headline:** The cake people ask for by name.  
**Body:** The signature yum! chocolate cake for birthdays, thank-yous, office celebrations, weddings, local pickup, and long-distance gifts.  
**CTA pair:** Order a Patticake / See how it works

---

# Example 9 — Baked by Melissa shipping FAQ → Patticake arrival confidence

## Reference mechanic

Specific shipping answers reduce anxiety.

## FAQ information architecture

1. Where can Patticake ship?
2. What dates can I request/select?
3. How far ahead should I order?
4. How is the cake packaged?
5. What happens when it arrives?
6. How should it be stored and served?
7. Can I include a gift message?
8. Can I ship to multiple addresses?
9. What if weather affects the shipment?
10. Is my request an order, or does the bakery confirm it first?

**Rule:** Do not publish answers until ops signs off.

---

# Example 10 — Maman/Tatte catering presentation → yum! office spread

## Reference mechanic

Elevated visuals can coexist with clear logistics.

## Shoot setup

- real conference-room or studio table
- box lunch opened, not stacked as anonymous boxes
- sandwich halves and salad bowls visible
- bakery tray as the finishing add-on
- human hand placing the last item
- branded packaging present but not dominating
- vertical master plus horizontal website image

## Ad draft

**Headline:** Office lunch people will actually eat.  
**Body:** Box lunches, sandwich platters, salads, and baked goods from yum!, available with advance notice for Twin Cities pickup.  
**CTA:** Get a Catering Quote

---

# Example 11 — Levain referral → Patticake box insert

## Front

> Someone sent you the cake people ask for by name.

## Back QR actions

- Send one
- Save a birthday
- Leave a review
- Follow yum!

Each QR uses a separate campaign parameter so the team can distinguish recipient behavior from sender behavior.

---

# Example 12 — Competitor mechanics → weekly operating dashboard

| Mechanic | Weekly question | Metric |
|---|---|---|
| Release cadence | Did the recurring format drive action? | Order clicks, saves, profile actions |
| Occasion page | Did specificity increase completion? | Route CTR and page CVR |
| Shipping trust | Did support burden fall? | Repetitive questions and completion rate |
| Office program | Did buyers repeat? | Second-order rate |
| Regional gifting | Did Minnesota affinity lower CAC? | CAC vs broad gifting audience |
| Location page | Did local intent convert? | Orders, calls, directions per session |
| Packaging insert | Did recipients re-enter the funnel? | QR scans, referrals, reminder opt-ins |
