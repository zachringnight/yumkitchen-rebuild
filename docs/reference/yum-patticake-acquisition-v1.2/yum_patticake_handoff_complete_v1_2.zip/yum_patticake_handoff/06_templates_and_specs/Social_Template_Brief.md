# Canva / Figma / Adobe Express Template Brief

## Goal

Build editable templates that non-designers can update without breaking brand quality.

## Template list

- Instagram Feed square post
- Instagram vertical Reel cover
- Instagram Story
- TikTok/Reel title card
- Facebook Feed post
- Pinterest Pin
- Meta paid ad square
- Meta paid ad vertical
- Google Business Profile post
- Catering lead-gen post
- Patticake birthday post
- Patticake thank-you gift post
- yum! menu feature post
- Bakery case drop post
- Gift card promo post
- Review/testimonial post

## Each template must include

- Editable headline
- Editable subheadline
- CTA area
- Image/video placeholder
- Logo placement
- Optional location tag
- Optional offer/deadline field
- Safe margins
- Export specs
- File naming convention

## What must never be changed

- Logo proportions.
- Brand-level hierarchy.
- Required safe zones.
- CTA legibility.
- Brand split: yum! for everyday/local food; Patticake for occasion/gifting.
- Operational claims unless confirmed by the business owner.

## Design direction

- Real food photography.
- Warm local bakery/restaurant feel.
- Clean enough for paid media.
- Not overly corporate.
- Not generic stock-style.
- Easy for non-designers to update.
