# Social and Creative Asset Folder Structure

```text
/assets
  /yum
    /locations
      /st-louis-park
      /shady-oak
      /st-paul
      /woodbury
    /menu
    /bakery
    /catering
    /staff
  /patticake
    /product
    /slice
    /shipping
    /pickup
    /occasions
    /corporate-gifting
    /weddings
  /ads
    /meta
    /google
    /tiktok
  /organic-social
    /instagram
    /facebook
    /tiktok
    /pinterest
    /youtube-shorts
    /google-business-profile
  /ugc
  /raw-footage
  /edited-exports
  /templates
    /canva
    /figma
    /adobe-express
  /logos
  /brand
```

## File naming convention

```text
brand_channel_campaign_assettype_location_date_version.ext
```

## Examples

```text
yum_ig_catering_boxlunch_reel_stpaul_2026-07-09_v01.mp4
patticake_meta_birthday_static_national_2026-07-09_v02.png
yum_gbp_bakerycase_photo_woodbury_2026-07-09_v01.jpg
patticake_ig_thankyou_story_shipping_2026-07-09_v01.mp4
```

## Versioning rules

- `v01` = first working export.
- `v02` = revised export.
- `FINAL` only after approval.
- Keep source files separate from exports.
- Do not use assets in paid ads unless usage rights are known.
