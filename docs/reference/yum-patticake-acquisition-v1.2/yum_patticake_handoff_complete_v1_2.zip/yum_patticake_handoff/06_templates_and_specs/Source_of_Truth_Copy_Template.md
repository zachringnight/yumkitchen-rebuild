# Source-of-Truth Copy Template

This document should be finalized by the business owner before paid media scale.

## yum! Kitchen & Bakery positioning

[Insert approved positioning. Recommended base: Made-from-scratch breakfast, lunch, dinner, bakery, and catering from neighborhood restaurants across the Twin Cities.]

## Patticake positioning

[Insert approved positioning. Recommended base: The signature cake from yum!, personalized for birthdays, thank-yous, office celebrations, weddings, and long-distance gifts.]

## Shipping language

Choose one:

### Option A — Ecommerce

Customers can order Patticake shipping directly online. Use “Order” and “Ship a Patticake.”

### Option B — Request-to-confirm

Customers must submit a request first. Use “Start a shipping request” and “We’ll confirm timing and availability.”

## Local pickup language

[Confirm pickup locations, notice requirements, timing, and customization options.]

## Catering language

[Confirm package types, notice requirements, pickup/delivery rules, minimums, and dietary/allergen disclaimer.]

## Wedding/event language

[Confirm what is offered: cakes, serving sizes, consultations, pickup/delivery/setup limitations.]

## Approved CTAs

- Order Online
- Get Directions
- Call Location
- Get Catering Quote
- Start Patticake Request
- Ship a Patticake
- Pick Up a Patticake
- Send a Thank-You Cake
- Plan Corporate Gifting
- Start Wedding/Event Inquiry
- Buy Gift Card

## Disallowed CTAs until confirmed

- Same-day shipping
- Nationwide guaranteed delivery
- Custom design guaranteed
- Delivery/setup included
- Lowest price/best price
- Any fake review/social proof claim
