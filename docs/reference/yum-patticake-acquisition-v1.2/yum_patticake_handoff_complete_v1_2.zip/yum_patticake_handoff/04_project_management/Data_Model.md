# Required Data Model

Even if handled through a form backend, Airtable, HubSpot, Toast, Klaviyo, Mailchimp, or Google Sheet, define these objects.

## Lead

| Field | Type | Notes |
|---|---|---|
| id | string | Unique ID |
| created_at | datetime | Submission timestamp |
| lead_type | enum | catering, cake_pickup, shipping, corporate_gifting, wedding_event, feedback |
| first_name | string | Required |
| last_name | string | Optional/required depending form |
| email | string | Required |
| phone | string | Required for high-intent leads |
| company | string | Required for B2B |
| event_date | date | Optional |
| occasion | enum | birthday, thank_you, wedding, office, holiday, etc. |
| location_preference | enum | restaurant/location selection |
| quantity | number | Cakes/items |
| guest_count | number | Catering/events |
| message | text | Customer notes |
| utm_source | string | Hidden field |
| utm_medium | string | Hidden field |
| utm_campaign | string | Hidden field |
| utm_content | string | Hidden field |
| utm_term | string | Hidden field |
| landing_page | string | Hidden field |
| referrer | string | Hidden field |
| status | enum | New, Contacted, Waiting, Quoted, Won, Lost, Follow-up later |
| owner | string | Internal owner |
| won_revenue | number | Manually entered or integrated |
| lost_reason | string | Optional |

## ConversionEvent

| Field | Type | Notes |
|---|---|---|
| event_name | string | Lowercase snake_case |
| timestamp | datetime | Event time |
| page_path | string | URL path |
| cta_label | string | Button/link label |
| brand | enum | yum, patticake |
| location | string | Location slug if relevant |
| lead_type | string | Lead type if relevant |
| campaign | string | UTM campaign |
| session_id | string | Anonymous session if available |

## Location

| Field | Type | Notes |
|---|---|---|
| slug | string | st-louis-park, shady-oak-minnetonka, st-paul, woodbury |
| name | string | Display name |
| address | string | Full address |
| phone | string | Click-to-call |
| hours | object | Structured hours |
| order_url | string | Location-specific order link |
| directions_url | string | Maps link |
| menu_url | string | Menu URL |
| image | string | Location hero |
| neighborhoods_served | array | SEO/local relevance |
