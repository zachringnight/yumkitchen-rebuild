# AI Coder Role Split

## AI Coder A — Architecture / Tracking

Owns:

- Analytics event map
- Tracking helper
- UTM capture
- CTA tracking wrapper
- Dashboard schema
- Form data structure
- Event QA

## AI Coder B — Frontend Components

Owns:

- Hero components
- CTA blocks
- Lead forms
- Sticky mobile CTA
- Location selector
- Card grids
- FAQ blocks
- Social proof blocks

## AI Coder C — Patticake Funnel

Owns:

- Product page cleanup
- Cake request/order form
- Occasion selector
- Birthday page
- Thank-you page
- Corporate gifting page
- Wedding/event page

## AI Coder D — yum! Local + Catering

Owns:

- Catering landing page
- Catering form
- Location page template
- Four location pages
- Gift card page
- Local SEO schema

## AI Coder E — QA / CRO / Performance

Owns:

- Broken link checks
- Event testing
- Form testing
- Mobile QA
- Page speed checks
- Schema validation
- CRO test setup
