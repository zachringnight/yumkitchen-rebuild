# Sprint Plan

## Sprint 0 — Setup and Audit

| Ticket | Priority | Owner |
|---|---|---|
| Crawl both sites | P0 | AI Coder A / QA |
| Create source-of-truth doc | P0 | Strategy / Content |
| URL decision map | P0 | AI Coder A |
| Analytics event map | P0 | AI Coder A |
| Asset inventory | P1 | Content / Design |

## Sprint 1 — Tracking and Conversion Base

| Ticket | Priority | Owner |
|---|---|---|
| Implement tracking helper | P0 | AI Coder A |
| Add UTM capture utility | P0 | AI Coder A |
| Build CTA wrapper | P0 | AI Coder B |
| Build generic lead form | P0 | AI Coder B |
| Build sticky mobile CTA | P0 | AI Coder B |

## Sprint 2 — Patticake Fix

| Ticket | Priority | Owner |
|---|---|---|
| Fix Patticake product page | P0 | AI Coder C |
| Remove placeholder review content | P0 | AI Coder C |
| Clarify checkout vs request language | P0 | AI Coder C / Owner |
| Build cake request/order form | P0 | AI Coder C |
| Add occasion selector | P1 | AI Coder C |

## Sprint 3 — Catering Funnel

| Ticket | Priority | Owner |
|---|---|---|
| Build catering landing page | P0 | AI Coder D |
| Build catering form | P0 | AI Coder D |
| Build catering package cards | P1 | AI Coder D |
| Add catering tracking events | P0 | AI Coder A |
| Add internal lead routing | P0 | Ops / AI Coder A |

## Sprint 4 — Location SEO Pages

| Ticket | Priority | Owner |
|---|---|---|
| Build location template | P1 | AI Coder D |
| Create four location pages | P1 | AI Coder D |
| Add schema | P1 | AI Coder D / SEO |
| Add internal linking | P1 | AI Coder D |
| Add location-specific tracking | P1 | AI Coder A |

## Sprint 5 — Patticake Growth Pages

| Ticket | Priority | Owner |
|---|---|---|
| Build occasion page template | P1 | AI Coder C |
| Birthday cake page | P1 | AI Coder C |
| Thank-you cake page | P1 | AI Coder C |
| Local pickup cake pages | P1 | AI Coder C |
| Corporate gifting page | P1 | AI Coder C |
| Wedding cake page | P1 | AI Coder C |

## Sprint 6 — Owned Audience + Reviews

| Ticket | Priority | Owner |
|---|---|---|
| Add email capture modules | P1 | AI Coder B / CRM |
| Create segmentation taxonomy | P1 | CRM |
| Create email automation specs | P1 | CRM / Strategy |
| Build review landing page | P1 | AI Coder B |
| Build QR tracking destinations | P1 | AI Coder A |

## Sprint 7 — Paid Landing Pages + Dashboard

| Ticket | Priority | Owner |
|---|---|---|
| Build paid landing page template | P1 | AI Coder B |
| Build office lunch catering LP | P1 | AI Coder D |
| Build birthday cake LP | P1 | AI Coder C |
| Build local cake pickup LP | P1 | AI Coder C |
| Define dashboard schema | P1 | AI Coder A / Data |
| Build dashboard | P1 | Data / AI Coder A |
