# yum! Kitchen & Bakery + Patticake.com Handoff Folder

This folder packages the full digital customer acquisition strategy, AI-coder build plan, social media asset/toolkit agent prompts, project-management files, tracking requirements, and QA standards for the yum! Kitchen & Bakery / Patticake.com acquisition system.

## How to use this handoff

1. Start with `00_start_here/Executive_Brief.md`.
2. Give `02_ai_coder_build_plan/AI_Coder_Project_Backlog.md` to technical builders.
3. Give `03_ai_agent_prompts/Social_Media_Asset_Toolkit_Agent_Prompt.txt` to the social/content AI agent.
4. Import `04_project_management/Project_Backlog.csv` into Linear, ClickUp, Jira, Notion, Trello, or GitHub Projects.
5. Use `05_tracking_and_qa/Analytics_Event_Map.csv` and `05_tracking_and_qa/QA_Checklists.md` as launch gates before paid media.
6. Use `08_competitive_benchmarks/Competitive_Benchmark_Executive_Summary.md` and `Benchmark_Inspired_Experiment_Backlog.csv` to build the first test roadmap.

## Strategic split

- **yum! Kitchen & Bakery** = everyday local food habit: restaurant, bakery, takeout, catering, gift cards, neighborhood demand.
- **Patticake** = occasion-based urgency: birthday cake, thank-you gift, shipped cake, local pickup, corporate gifting, weddings/events.

## Immediate build order

1. Fix contradictions and source-of-truth copy.
2. Track every primary CTA and form.
3. Build reusable conversion components.
4. Fix Patticake order/request funnel.
5. Build catering lead funnel.
6. Build local SEO pages.
7. Build Patticake occasion pages.
8. Add CRM/list/review/referral loops.
9. Add paid landing pages.
10. Launch dashboard and CRO testing.

## Folder structure

```text
yum_patticake_handoff/
  00_start_here/
  01_strategy/
  02_ai_coder_build_plan/
  03_ai_agent_prompts/
  04_project_management/
  05_tracking_and_qa/
  06_templates_and_specs/
  07_tool_stack_and_ai_operating_system/
  08_competitive_benchmarks/
```

## Notes for owners

Do not treat this as a website refresh. Treat it as a conversion infrastructure build. The business goal is measurable acquisition: orders, directions, calls, catering leads, cake requests/orders, gift card clicks, email/SMS opt-ins, and repeat purchase loops.


## 07_tool_stack_and_ai_operating_system

Recommended AI models, apps, templates, workflow ownership, agent roster, setup checklists, and budget tiers for executing the acquisition build without tool sprawl.

Files:

- `Tool_Stack_Recommendation.md`
- `AI_Model_Routing_Guide.md`
- `Templates_Apps_Setup_Checklist.md`
- `Tool_Stack_Matrix.csv`
- `AI_Agent_Roster.csv`


## 08_competitive_benchmarks

Current official examples, brand-mechanic analysis, swipe-file templates, AI research prompt, experiment backlog, and a 90-day benchmark-inspired test plan.

Files:

- `README.md`
- `Competitive_Benchmark_Playbook.md`
- `Brand_Benchmark_Matrix.csv`
- `Live_Example_Links.csv`
- `Benchmark_Inspired_Experiment_Backlog.csv`
- `Competitive_Swipe_File_Template.csv`
- `Creative_Deconstruction_Worksheet.md`
- `AI_Competitive_Research_Agent_Prompt.txt`
- `90_Day_Benchmark_Test_Plan.md`
- `Social_Content_Archetypes.md`
