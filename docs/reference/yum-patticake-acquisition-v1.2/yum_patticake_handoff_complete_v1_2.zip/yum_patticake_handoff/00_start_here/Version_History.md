# Version History

## v1.2 — Competitive benchmark expansion — July 10, 2026

- Added `08_competitive_benchmarks/` with current official examples.
- Added a 12-brand benchmark matrix and 39 live reference links.
- Added 30 benchmark-inspired experiments and a 90-day test plan.
- Added client-ready benchmark summary and concrete execution examples.
- Added monthly competitive-research AI agent prompt and swipe-file/deconstruction templates.
- Added 10 benchmark-derived tickets to the master project backlog.
- Updated README and executive brief.

## v1.1 — Tool stack expansion — July 10, 2026

- Added AI model routing, app stack, setup checklist, tool matrix, and agent roster.

## v1.0 — Initial acquisition handoff — July 10, 2026

- Added acquisition strategy, AI coder plan, social toolkit prompt, project-management files, tracking plan, templates, and QA standards.
