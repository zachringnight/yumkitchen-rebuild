# Executive Brief

## Program name

**yum! + Patticake Digital Acquisition Engine**

## Goal

Build a measurable acquisition system that turns local search, social content, paid media, email/SMS, and referral/review loops into restaurant orders, catering leads, Patticake cake orders/requests, corporate gifting leads, wedding/event inquiries, gift card purchases, and repeat customers.

## Strategic diagnosis

The strongest business move is not to merge yum! and Patticake into one vague brand. The stronger architecture is:

- **yum! Kitchen & Bakery** owns local Twin Cities demand: breakfast, lunch, dinner, bakery case, takeout, catering, gift cards, local cake pickup.
- **Patticake** owns celebration/gifting demand: birthdays, thank-yous, corporate gifting, shipped cake, local pickup, weddings/showers/events.

## Priority leaks to fix before serious paid spend

1. Remove contradictory copy around shipping, delivery, pickup, and request/checkout flow.
2. Remove any visible placeholder or sample review language.
3. Make Patticake conversion explicit: either ecommerce checkout or request-to-confirm.
4. Stop sending paid traffic to generic pages.
5. Track all CTAs and all forms.
6. Capture UTM parameters on all forms.
7. Build pages for specific buyer intent: catering, birthday cake, thank-you cake, local pickup, corporate gifting, weddings/events, each restaurant location.

## First 10 tickets

| Order | Ticket | Priority |
|---:|---|---|
| 1 | Crawl yumkitchen.com and patticake.com | P0 |
| 2 | Create source-of-truth messaging doc | P0 |
| 3 | Create URL redirect/canonical map | P0 |
| 4 | Create analytics event map | P0 |
| 5 | Build CTA tracking wrapper | P0 |
| 6 | Build UTM capture utility | P0 |
| 7 | Build reusable lead form | P0 |
| 8 | Fix Patticake product page copy and CTA flow | P0 |
| 9 | Build catering landing page and form | P0 |
| 10 | Build reporting/dashboard schema | P1 |

## Non-negotiable launch gates

A page or funnel is not ready for paid traffic until it has:

- Clear primary CTA.
- Correct destination.
- Mobile sticky CTA where appropriate.
- CTA analytics events.
- Form analytics events.
- UTM capture.
- Error and success states.
- No placeholder content.
- No unsupported operational claims.
- SEO title/meta.
- Image alt text.
- QA pass on desktop and mobile.


## Benchmark-informed execution

Use `08_competitive_benchmarks/` to translate category-leading mechanics into tests. The priority stack is:

1. Crumbl-style recurring content cadence without high SKU churn.
2. Milk Bar/Baked by Melissa-level shipping clarity.
3. Nothing Bundt Cakes-style occasion merchandising.
4. Levain/Tiff's Treats-style corporate gifting operations and recurring office programs.
5. Portillo's-style regional nostalgia for shipped Patticake acquisition.
6. Sweetgreen-style transactional local pages for all four yum! locations.

Copy mechanics, not identities. Every imported idea must pass an operational-realism check and have a measurable KPI.
