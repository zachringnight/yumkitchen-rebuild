# Digital Customer Acquisition Strategy: yum! Kitchen & Bakery + Patticake

## Executive thesis

Treat this as **two connected acquisition businesses**, not one generic restaurant campaign.

**yum! Kitchen & Bakery** should own **Twin Cities local demand**: breakfast, lunch, dinner, bakery case, takeout, office catering, gift cards, and wedding/custom cake pickup.

**Patticake.com** should own **celebration and gifting demand**: birthdays, thank-yous, office celebrations, family moments, weddings/showers, local pickup, and shipped cakes.

The main acquisition move: **use yum! to create local frequency and trust; use Patticake to turn that trust into higher-intent gifting, catering, and celebration purchases.**

---

# 1. Business objectives

| Business line | Acquisition goal | Conversion event | 90-day KPI target |
|---|---:|---|---:|
| yum! local restaurant | Increase first-party pickup/delivery orders | online order click, call, directions click | +15–25% first-party online orders |
| yum! catering | Acquire office/team/event buyers | catering lead, call, quote request, booked order | 100–200 qualified leads / quarter |
| Patticake local pickup | Own Twin Cities birthday/celebration cake demand | pickup cake order/inquiry | 150–300 cake orders / quarter |
| Patticake shipping | Build DTC gifting channel | shipped cake purchase or shipping lead | CAC-stable paid test by day 90 |
| Gift cards | Capture seasonal and gratitude demand | gift card purchase/click | build holiday/event-driven spikes |
| CRM/list growth | Build repeatable owned audience | email/SMS opt-in | +2,500–5,000 qualified contacts/year |

---

# 2. Brand architecture

## yum! Kitchen & Bakery = local everyday hospitality

**Positioning:**

Made-from-scratch breakfast, lunch, dinner, bakery, and catering from four neighborhood restaurants across the Twin Cities.

**Primary calls to action:**

- Order from nearest yum!
- Plan catering
- View menu
- Buy gift cards
- Pick up a cake locally

## Patticake = giftable celebration cake

**Positioning:**

The signature chocolate cake from yum!, made fresh, personalized with a message, and ready for pickup or shipping.

**Primary calls to action:**

- Ship a Patticake
- Pick up locally
- Send a birthday cake
- Send a thank-you cake
- Plan office gifting
- Plan wedding or celebration cake

## Required site cleanup

1. **Decide whether Patticake shipping is ecommerce or concierge.**
   - If customers can pay online, every page should say “Order now.”
   - If bakery confirmation is required, every page should say “Start a shipping request.”
   - Do not mix both.

2. **Redirect or update old yumkitchen.com cake pages.**
   - Any page saying “we do not ship or deliver” must either be updated or redirected to the current Patticake pickup/shipping experience.

3. **Use canonical domain rules.**
   - Keep yumkitchen.com for local restaurant SEO and Patticake.com for cake/gifting SEO, or fully migrate one into the other.
   - Do not let both domains compete with duplicate pages.

4. **Add conversion-specific landing pages.**
   - Paid traffic should not go to generic homepages.

---

# 3. Core customer segments

## Segment 1: Neighborhood regulars

**Who:** Families, professionals, parents, retirees, local residents near St. Louis Park, Minnetonka/Shady Oak, St. Paul, and Woodbury.  
**Need:** Easy breakfast/lunch/dinner, reliable takeout, bakery case.  
**Acquisition channels:** Google Maps, Google Search, Instagram, neighborhood creators, email/SMS, review flywheel.  
**Offer:** Order from your nearest yum! + seasonal bakery add-on.

## Segment 2: Office lunch and catering buyers

**Who:** Office managers, HR, executive assistants, sales teams, medical offices, schools, real estate teams, agencies, local business owners.  
**Need:** Reliable boxed lunches, sandwich platters, salads, baked goods, easy pickup, repeatable ordering.  
**Acquisition channels:** Google Search, LinkedIn outreach, retargeting, email nurture, Google Business Profile posts, local B2B partnerships.  
**Offer:** Office lunch that does not feel like sad catering.

## Segment 3: Celebration cake buyers

**Who:** Parents, spouses, friends, party hosts, wedding/shower planners, coworkers.  
**Need:** Birthday cake, thank-you cake, office celebration cake, wedding/shower cake.  
**Acquisition channels:** Google Search, Meta/Instagram, Pinterest, wedding marketplaces, email reminders.  
**Offer:** The cake people ask for by name.

## Segment 4: Long-distance gift senders

**Who:** Former Minnesotans, family members, college parents, corporate gift buyers, sales/client success teams.  
**Need:** A personal food gift that feels more thoughtful than flowers or a generic gift basket.  
**Acquisition channels:** Meta, Google Search/Shopping if applicable, paid social retargeting, corporate gifting outreach, referral program.  
**Offer:** Send a real yum! Patticake to someone you miss.

## Segment 5: Wedding and event planners

**Who:** Couples, parents, planners, venues, photographers, coordinators.  
**Need:** Wedding cake, shower cake, dessert table, celebration pickup.  
**Acquisition channels:** Wedding marketplaces, Google Search, Pinterest, Instagram, vendor partnerships.  
**Offer:** A wedding cake people actually want to eat.

---

# 4. Offer ladder

## Local yum! ladder

| Funnel stage | Offer | Purpose |
|---|---|---|
| First visit | Order pickup from your nearest yum! | Convert search/local intent |
| First online order | Bakery add-on prompt | Raise AOV |
| Second order | Next lunch reminder | Build habit |
| Family dinner | Family-style bundles | Increase ticket size |
| Catering | First catering order incentive | Convert B2B buyers |
| Gift cards | Seasonal bonus card promo | Acquire prepaid future visits |

## Patticake ladder

| Funnel stage | Offer | Purpose |
|---|---|---|
| First cake | Signature Patticake | Hero product |
| Local celebration | Pickup cake with message | Low-friction local conversion |
| Shipped gift | Ship a Patticake | National expansion |
| Office/team | Multi-recipient gifting | Higher AOV |
| Wedding/shower | Tiered Patticake or cake consultation | High-value event lead |
| Reminder program | Birthday/anniversary reminders | Repeat purchase engine |

---

# 5. Funnel architecture

## Funnel A: Local restaurant acquisition

Google Search / Maps / Instagram / creators  
→ location page  
→ menu or online ordering  
→ online order / directions / call  
→ email/SMS capture  
→ second-order automation  
→ catering or cake upsell

## Funnel B: Catering acquisition

Search / LinkedIn / email / retargeting  
→ Twin Cities office lunch catering landing page  
→ menu + minimums + lead form + call button  
→ quote/order  
→ post-event follow-up  
→ monthly repeat program

## Funnel C: Patticake acquisition

Gift trigger / paid social / search / email / referral  
→ occasion-specific landing page  
→ product page  
→ checkout or shipping request  
→ confirmation  
→ gift recipient opt-in  
→ reminder/referral sequence

This funnel must be clarified before paid spend. If the conversion is a form, call it a request. If it is checkout, make it true checkout.

---

# 6. Channel strategy

## A. Local SEO and Google Business Profiles

Highest-leverage foundation for yum!.

### Actions

- Fully optimize each location profile:
  - correct hours
  - menu URL
  - order URL
  - catering URL
  - cake pickup URL
  - photos of exterior, counter, bakery case, top dishes, catering trays
  - attributes for takeout, pickup, delivery, dine-in where applicable
- Add structured menu sections with dishes, descriptions, and prices.
- Post weekly:
  - seasonal menu item
  - bakery case feature
  - catering reminder
  - gift card promo
  - cake pickup reminder
- Reply to every review within 72 hours.
- Build a review request flow:
  - QR cards in pickup bags
  - post-order email
  - catering follow-up email
  - “Mention your favorite menu item” prompt to get keyword-rich reviews

### SEO pages to build

For yum!:

- `/locations/st-louis-park`
- `/locations/shady-oak-minnetonka`
- `/locations/st-paul`
- `/locations/woodbury`
- `/catering/twin-cities-office-lunch`
- `/catering/boxed-lunches-minneapolis`
- `/catering/sandwich-platters-st-paul`
- `/bakery/twin-cities`
- `/gift-cards`

For Patticake:

- `/ship-birthday-cake`
- `/ship-thank-you-cake`
- `/corporate-gifting`
- `/birthday-cake-pickup-minneapolis`
- `/birthday-cake-pickup-st-paul`
- `/wedding-cakes-twin-cities`
- `/chocolate-cake-delivery`
- `/send-a-cake`

## B. Paid Google Search

Start with intent. Do not start with broad awareness.

| Campaign | Keywords | Landing page | Goal |
|---|---|---|---|
| Brand | yum kitchen, yum bakery, patticake, yum patticake | Best matching brand page | Protect demand |
| Local restaurant | lunch near me, bakery near me, breakfast Woodbury, takeout St. Louis Park | Location pages | Orders/directions |
| Catering | boxed lunch catering Minneapolis, office lunch catering Twin Cities | Catering page | Leads/calls |
| Cakes local | birthday cake Minneapolis, cake pickup St. Paul, wedding cake Twin Cities | Cake pickup/wedding pages | Orders/leads |
| Shipped cake | ship birthday cake, send chocolate cake, cake delivery gift | Patticake shipping pages | Orders/leads |
| Competitor conquest | local bakery/catering competitors | Dedicated comparison/offer page | Incremental leads |

## C. Meta / Instagram paid social

Use Meta for **visual demand creation**, not just last-click conversion.

| Campaign | Objective | Audience | Creative |
|---|---|---|---|
| Local orders | Sales / traffic to order | 3–7 mile radius around each store | Food, bakery case, staff, takeout |
| Catering leads | Leads | Business-heavy ZIPs, retargeting, uploaded customer lists | Box lunches, office spreads |
| Patticake pickup | Sales/leads | Twin Cities, parents, celebrations, engaged site visitors | Cake slice, message, pickup |
| Patticake shipping | Sales/leads | Midwest/national test, gift buyers, ex-MN interest clusters | Unboxing, delivery, message |
| Retargeting | Sales/leads | Site visitors, IG engagers, form opens, cart abandons | Social proof, urgency, FAQ |

### Creative rule

No polished stock-feeling restaurant ads. Use real food, real hands, real counters, real boxes, real frosting, real staff.

## D. TikTok, Reels, Shorts

Short-form video should be a creative lab. Post organically, then boost winners.

### Content pillars

1. Patticake slice pull / cake cut
2. “Pack a cake with us” shipping/pickup sequence
3. Office catering tray build
4. Bakery case morning restock
5. Soup + sandwich comfort
6. “What $15–$20 gets you at yum!”
7. Staff favorites
8. Customer occasion stories
9. Wedding cake behind the scenes
10. Minnesota nostalgia / local love

Cadence: **5–7 short videos per week**.

## E. Email and SMS

Owned audience should make acquisition cheaper over time.

### Core automations

| Automation | Audience | Trigger | CTA |
|---|---|---|---|
| Welcome | New email captured | First order/sign-up | Order again / nearest location |
| Second-order push | First-time customer | 7–10 days after first order | Come back for lunch |
| Lapsed guest | No order in 45–60 days | Inactivity | Seasonal favorite |
| Catering nurture | Catering page visitor/form submitter | Lead or visit | Plan next office lunch |
| Birthday reminder | Birthday captured | 14 days before | Order Patticake |
| Gift reminder | Gift buyer | 60–90 days after purchase | Send another |
| High-spender thank-you | Top customers | Spend threshold | Gift card/catering/cake |
| Holiday campaign | Full list | Seasonal | Gift cards + cakes |

Use SMS only for high-intent moments: order-ready reminders, same-week cake pickup, catering confirmation, limited seasonal cake drop, holiday gift card deadlines.

## F. Influencers and local creators

Use micro-creators who can drive local credibility.

### Creator types

- Twin Cities food creators
- mom/parenting creators
- local office/work lifestyle creators
- wedding planners
- photographers
- college parent communities
- Minnesota nostalgia creators
- neighborhood accounts near each location

### Creator briefs

- Best thing to order at yum! if it’s your first time
- Pack an office lunch with yum! catering
- The cake Twin Cities people ask for by name
- Send a Patticake to someone who moved away
- Wedding cake that tastes like an actual dessert

## G. B2B catering acquisition

Treat catering like a sales funnel, not passive website traffic.

### Target lists

- medical/dental offices
- law firms
- agencies
- real estate brokerages
- financial advisors
- schools
- churches
- nonprofits
- tech companies
- athletic departments
- event venues
- corporate campuses

### Landing page must include

- box lunch photos
- top 5 packages
- serving sizes
- notice requirements
- pickup details
- call button
- quote form
- dietary/allergen guidance
- office testimonial
- repeat lunch program option

---

# 7. Paid media budget

## Starter budget: $8K–$12K/month

| Spend bucket | % | Purpose |
|---|---:|---|
| Google Search | 35% | Capture high-intent local/catering/cake demand |
| Meta/Instagram | 25% | Demand creation + retargeting |
| Creative production | 15% | Short-form video, product photos, UGC |
| SEO/content | 10% | Landing pages and local content |
| Email/SMS/CRM | 5% | Automations and list growth |
| Creator seeding | 10% | Local proof and UGC |

## Growth budget: $20K–$30K/month

| Spend bucket | % | Purpose |
|---|---:|---|
| Google Search + Local campaigns | 30% | Local orders, directions, catering leads |
| Meta/Instagram | 25% | Cake, catering, restaurant demand |
| TikTok/Reels/Shorts boosting | 10% | Creative discovery |
| SEO/content/CRO | 10% | Landing pages, conversion optimization |
| Email/SMS/loyalty | 7.5% | Repeat and owned audience |
| Creators/PR | 10% | Social proof |
| Testing reserve | 7.5% | Seasonal, gifting, wedding tests |

## CAC guardrails

**Allowable CAC = gross profit on first order + expected 90-day repeat gross profit**

Do not judge all channels by the same CAC. Catering and corporate gifting can support higher acquisition costs because order value and repeat potential are materially higher.

---

# 8. Landing page system

## yum! local location page

Above the fold:

- location name
- hours
- order button
- directions button
- call button
- parking note
- top 5 menu favorites
- bakery/catering/cake links

Conversion CTAs:

- Order online
- Get directions
- Call location
- Plan catering
- Pick up a cake

## Catering page

**Headline:** Twin Cities office lunch catering that people actually look forward to.

Sections:

- box lunches
- sandwich platters
- salads
- baked goods
- notice requirements
- pickup locations
- dietary notes
- first-order offer
- quote form
- call button

## Patticake shipping page

**Headline:** Send the signature yum! Patticake anywhere it can safely travel.

Sections:

- product photo
- cake size and servings
- message/gift note
- shipping timing
- checkout or request flow
- FAQs
- social proof
- corporate gifting link
- local pickup alternative

## Corporate gifting page

**Headline:** Send cake to clients, teams, and people worth thanking.

Sections:

- bulk gifting use cases
- multi-address support
- lead time
- branded note option if available
- minimums
- sample package
- quote form
- sales contact

## Wedding cakes page

**Headline:** A wedding cake people remember for how it tastes.

Sections:

- Patticake story
- gallery
- starting packages
- serving guide
- pickup/delivery/setup clarity
- inquiry form
- venue/vendor partner logos
- testimonials

---

# 9. Creative strategy

## Core message pillars

| Pillar | Message | Best channel |
|---|---|---|
| Signature cake | The cake people ask for by name. | Meta, TikTok, Search, email |
| Made from scratch | Real food, real bakery, made daily. | Local SEO, social, website |
| Easy neighborhood meal | Breakfast, lunch, dinner, bakery — open daily. | Google, Maps, Meta |
| Catering reliability | Office lunch without the disappointment. | Search, LinkedIn, email |
| Giftability | Send a cake with a message that feels personal. | Meta, email, Google |
| Local trust | Four Twin Cities restaurants behind every cake. | Website, PR, retargeting |

## Ad hooks

### yum! local

- Your neighborhood breakfast, lunch, dinner, and bakery stop.
- Order pickup from the yum! closest to you.
- Soup, sandwiches, salads, bakery, and dinner — made from scratch.
- Office lunch? Bring yum!.

### Patticake

- Send the cake Minnesotans ask for by name.
- A birthday cake that feels personal, even from far away.
- Chocolate cake, vanilla buttercream, real message, real yum! bakery.
- For the person you miss, thank, love, or need to celebrate.

### Catering

- Boxed lunches that do not feel boxed-in.
- The team lunch upgrade.
- Sandwich platters, salads, baked goods, and 24-hour pickup.

---

# 10. 90-day execution plan

## Days 1–14: Fix the funnel

- Resolve shipping vs no-shipping contradictions.
- Remove sample review language.
- Clarify checkout vs request flow.
- Add dedicated landing pages for catering, Patticake shipping, Patticake local pickup, corporate gifting, and each location.
- Install/verify GA4, Google Ads conversion tags, Meta pixel + Conversions API, call tracking, UTM standards, form events, and order attribution where possible.
- Audit all four location profiles.
- Start review reply cadence.
- Segment CRM contacts by customer type and interest.

## Days 15–30: Launch acquisition tests

- Launch branded search.
- Launch catering search.
- Launch local restaurant search around each location.
- Launch cake pickup and wedding cake search.
- Launch Patticake shipping test only after conversion flow is fixed.
- Launch paid social creative groups: local food, bakery/cake, catering, gifting.
- Publish 20–30 short-form videos.
- Seed 10–15 local creators.

## Days 31–60: Optimize and scale

- Kill weak creatives.
- Shift budget toward lowest CAC / highest AOV campaigns.
- Launch catering outbound.
- Add corporate gifting page.
- Build birthday reminder program.
- Add review request QR to every pickup/catering order.
- Create first catering order offer.
- Launch wedding/vendor partnership outreach.

## Days 61–90: Build repeatable growth loops

- Launch monthly office lunch program.
- Launch send-a-cake-again email/SMS flow.
- Launch gift recipient referral.
- Build seasonal drop calendar.
- Test Mother's Day, Father's Day, graduation, back-to-school, Thanksgiving, holiday gifting, Q4 corporate gifting.
- Create quarterly content shoots for future paid creative.

---

# 11. Measurement dashboard

| Area | Metrics |
|---|---|
| Local restaurant | Orders, online conversion rate, calls, direction clicks, AOV, new vs returning customers |
| Google Business Profile | searches, menu clicks, order clicks, calls, direction requests, photo views, reviews |
| Catering | leads, qualified leads, booked orders, AOV, close rate, repeat rate, CAC |
| Patticake | page conversion rate, add-to-cart/request starts, submits, AOV, CAC, repeat orders |
| Email/SMS | list growth, revenue per send, open/click, conversion rate, unsubscribe rate |
| Paid media | spend, CAC, ROAS, CTR, CVR, frequency, creative winner rate |
| Reviews | review count, rating, response time, keyword mentions |
| Creative | thumb-stop rate, hook retention, saves, shares, comments, cost per engaged visitor |

## Weekly operating cadence

Every Monday:

1. Review spend by channel.
2. Review conversions by business line.
3. Identify top 3 creatives.
4. Identify worst 3 landing page leaks.
5. Reallocate 10–20% of budget.
6. Assign one conversion fix and one creative sprint.

No vague brand-awareness reporting. Tie every channel to orders, leads, list growth, or qualified local traffic.

---

# 12. Priority actions

## Do first

1. Fix the Patticake checkout/request contradiction.
2. Update or redirect old cake pages with outdated shipping/delivery copy.
3. Remove sample review language from live pages.
4. Build dedicated landing pages for catering, Patticake shipping, local pickup, and corporate gifting.
5. Optimize all Google Business Profiles.
6. Launch Google Search for catering and cake intent.
7. Turn on email automations.
8. Create 30 short-form videos in 30 days.

## Do not do yet

- Do not pour budget into broad Meta prospecting until the Patticake conversion path is clean.
- Do not use generic restaurant stock creative.
- Do not discount the brand into commodity territory.
- Do not send all paid traffic to the homepage.
- Do not let yum! and Patticake compete against each other in SEO.

---

# Recommended acquisition positioning

## yum! Kitchen & Bakery

**Made-from-scratch breakfast, lunch, dinner, bakery, and catering from four Twin Cities neighborhood restaurants.**

## Patticake

**The signature chocolate cake from yum!, personalized for birthdays, thank-yous, office celebrations, weddings, and long-distance gifts.**

That is the strategic split: **yum! creates local habit; Patticake creates occasion-based urgency.**
