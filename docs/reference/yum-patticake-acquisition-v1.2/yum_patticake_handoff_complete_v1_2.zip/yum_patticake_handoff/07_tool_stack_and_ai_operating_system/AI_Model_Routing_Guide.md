# AI Model Routing Guide

## Principle

Do not pick one model for everything. Route work based on task type.

---

# Recommended Model/Tool Routing

| Work Type | Best Primary Choice | Backup / Second Opinion | Human Review Required? |
|---|---|---|---|
| Strategy | ChatGPT / GPT-5-class reasoning model | Claude Opus/Sonnet | Yes |
| Research synthesis | ChatGPT deep research / Gemini deep research | Claude | Yes |
| Prompt writing | ChatGPT | Claude | Light review |
| Brand voice/copy | ChatGPT custom GPT | Claude | Yes |
| Social caption variants | ChatGPT | Canva AI / Buffer AI | Yes |
| Short-form scripts | ChatGPT | Gemini / Claude | Yes |
| Code tickets | ChatGPT + Cursor | GitHub Copilot | Yes |
| Code implementation | Cursor | GitHub Copilot coding agent / Codex | Yes |
| UI prototypes | v0 | Cursor | Yes |
| Code review | Claude + ChatGPT | GitHub Copilot | Yes |
| Large document review | Gemini long-context / ChatGPT | Claude | Yes |
| Image concepts | Adobe Firefly / ChatGPT image / Canva AI | Figma/Canva layout | Yes |
| Real product imagery | Human photo/video shoot | AI cleanup only | Yes |
| Video editing support | CapCut / Adobe Express / Descript | Premiere Pro | Yes |
| Automations | Zapier Copilot/Agents | Make/custom code | Yes |
| Lead summaries | HubSpot Breeze / ChatGPT | Zapier AI | Yes before external send |

---

# Model Use Rules

## ChatGPT

Use for:
- Operating plans
- Strategy documents
- Prompt libraries
- Campaign ideas
- Captions
- QA checklists
- Weekly performance reviews
- Code ticket writing
- Agent design

Do not use blindly for:
- Final published pricing/hours claims without source check
- Final legal/privacy copy
- Final allergen/ingredient claims
- Final operational promises about shipping, delivery, or order deadlines

## Claude

Use for:
- Second-pass code review
- Alternative copy direction
- Long-form rewrite critique
- Edge-case review of AI-generated plans

Best use:
- Ask Claude to challenge ChatGPT's output, not just repeat it.

## Gemini

Use for:
- Long-context file review
- Multimodal/video analysis
- Large asset libraries
- Long source documents
- Optional Google Search-grounded research workflows

Best use:
- Big context jobs where many files or long videos need synthesis.

## Cursor

Use for:
- Codebase edits
- Refactors
- Frontend components
- Analytics/event implementation
- Forms and UTM capture
- Bug fixes

Rules:
- One branch per ticket.
- No unrelated changes.
- Run tests/build.
- Submit PR for review.

## v0

Use for:
- Landing-page sections
- Component prototypes
- Dashboard UI prototypes
- Form layouts
- Shadcn/Tailwind/React starting points

Rule:
- v0 creates drafts. Cursor/engineer owns production integration.

## Canva AI / Adobe Firefly / Figma AI

Use for:
- Social layout variations
- Background cleanup
- Moodboards
- Template creation
- Image extension/cropping
- Concepting

Do not use for:
- Fake images of actual menu items presented as real food
- Fake customer photos
- Fake testimonials
- Fake packaging claims

---

# Recommended Custom GPT / Agent Set

1. Acquisition PM Agent
2. Social Creative Director Agent
3. Social QA Agent
4. AI Coder PM Agent
5. Landing Page/Funnel QA Agent
6. Analytics QA Agent
7. Catering Sales Follow-Up Agent
8. Creator/UGC Coordinator Agent
9. Email Lifecycle Agent
10. Weekly Reporting Agent

Each agent should have:
- Role
- Inputs
- Outputs
- Forbidden actions
- QA checklist
- Source-of-truth files
- Example prompts

---

# Decision Rule

Use the highest-reasoning model for decisions. Use cheaper/faster AI for variants and production. Use human review for anything public-facing, revenue-facing, or operationally binding.