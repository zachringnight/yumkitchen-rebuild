# Tool Stack + AI Operating System

## Purpose

This document defines the recommended AI models, software tools, templates, apps, and workflow ownership for building the yum! Kitchen & Bakery + Patticake acquisition engine.

The goal is not to collect tools. The goal is to create one operating system where strategy, creative, code, analytics, and lead follow-up connect cleanly.

---

# 1. Recommended Core Stack

## The lean version

Use this if the team wants speed and does not want tool sprawl.

| Function | Recommended Tool | Why | Owner |
|---|---|---|---|
| AI command center | ChatGPT Pro or ChatGPT Business | Strategy, research, prompt systems, QA, reusable agents, docs, Codex access where available | Founder / PM |
| Code implementation | Cursor + GitHub | Best daily workflow for AI-assisted coding against an existing repo | Developer / AI coder |
| UI/landing-page prototyping | v0 by Vercel | Fast generation of React/Next.js/Tailwind landing page components and prototypes | Developer / designer |
| Design source of truth | Figma | Master design system, web components, wireframes, review, handoff | Designer / PM |
| Social production templates | Canva Teams | Fast editable social assets for non-designers | Social/content manager |
| Image/video AI support | Adobe Firefly / Adobe Express | Generative creative support, campaign variations, social templates | Designer / content manager |
| Social scheduling | Buffer | Scheduling, planning, analytics, and community management across the required social channels | Social/content manager |
| Lead database / ops hub | Airtable | Lead tracker, content calendar, creator CRM, asset library, lightweight dashboards | Ops / marketing |
| CRM / sales follow-up | HubSpot Starter or Professional | Catering, corporate gifting, wedding/event pipeline, email nurture if not handled elsewhere | Sales / ops |
| Restaurant CRM/email | Toast Marketing | Existing restaurant guest marketing, order-linked email campaigns, local repeat customer flows | Restaurant marketing |
| Automations | Zapier | No-code app connections, lead routing, notifications, AI workflow automation | Ops / AI implementer |
| Analytics | GA4 + Google Tag Manager + Looker Studio | Event tracking, attribution, dashboarding | Marketing / analytics |
| Paid media | Google Ads + Meta Ads Manager + TikTok Ads Manager | Search capture, local demand, retargeting, paid social tests | Media buyer |
| File storage | Google Drive or Dropbox | Asset library, handoff docs, approvals | Everyone |
| Project management | Linear, ClickUp, or Notion | Ticketing, sprint plan, owners, deadlines | PM |

## Best default stack

For this project, the recommended default is:

1. **ChatGPT Business** for strategy, agent workflows, content QA, and shared workspace memory.
2. **Cursor + GitHub** for code execution.
3. **v0** for landing page prototypes/components.
4. **Figma** for master design system and web page layouts.
5. **Canva Teams** for social production templates.
6. **Airtable** for lead/content/asset databases.
7. **HubSpot** for sales CRM only if catering, corporate gifting, and wedding/event leads need structured follow-up.
8. **Toast Marketing** for existing restaurant customer email flows.
9. **Buffer** for social scheduling and reporting.
10. **Zapier** for automation glue.
11. **GA4/GTM/Looker Studio** for measurement.

---

# 2. Tool Stack by Workflow

## Workflow A — Strategy, planning, QA, and agent orchestration

| Need | Use | Templates to create |
|---|---|---|
| Strategy updates | ChatGPT | Strategy update prompt, channel audit prompt, weekly report prompt |
| AI agents | ChatGPT Business workspace agents or custom GPTs | Social Creative Director, Funnel QA Agent, AI Coder PM, Analytics QA Agent |
| Long-form documents | ChatGPT + Notion/Google Docs | Acquisition plan, sprint plan, source-of-truth doc |
| Project memory | Notion or Google Drive | Handoff folder, brand rules, approved copy bank |
| Team workflow | ClickUp, Linear, or Notion | Sprint board, ticket template, QA checklist |

**Recommendation:** Use ChatGPT Business if multiple team members will touch the same agent workflows. Use ChatGPT Pro if one person is running everything.

---

## Workflow B — AI coding and site build

| Need | Use | Why |
|---|---|---|
| Existing repo changes | Cursor | Strong for in-repo multi-file edits, codebase questions, refactors |
| Git workflow | GitHub | Branches, pull requests, reviews, issue tracking |
| Cloud coding agent | GitHub Copilot coding agent or ChatGPT Codex | Good for ticket-based repo changes and PRs |
| UI generation | v0 by Vercel | Fast landing page/component prototypes |
| Quick internal app prototype | Lovable | Useful for lead dashboards, forms, and admin tools if code ownership is not critical |
| Human review | GitHub pull requests | Never let AI merge directly to production |

## Coding templates to create

- `.cursor/rules` or project rules file
- `AI_CODER_TICKET_TEMPLATE.md`
- `PULL_REQUEST_TEMPLATE.md`
- `QA_CHECKLIST.md`
- `ANALYTICS_EVENT_MAP.md`
- `FORM_FIELD_SPEC.md`
- `LANDING_PAGE_COMPONENT_SPEC.md`
- `REDIRECT_AND_CANONICAL_MAP.md`

## Recommended coding workflow

1. Human creates ticket from the backlog.
2. AI coder works in Cursor or GitHub Copilot agent.
3. AI coder submits PR.
4. QA agent checks: build, links, forms, tracking, mobile, schema.
5. Human approves.
6. Deploy.

**Rule:** AI can write the code. A human owns the merge.

---

## Workflow C — Landing pages and website conversion

| Need | Use | Notes |
|---|---|---|
| Wireframes | Figma | Create reusable page sections before coding |
| Page/component prototypes | v0 | Use for hero, lead forms, card grids, FAQs, sticky CTAs |
| Production implementation | Existing CMS/repo + Cursor | Do not rebuild the whole site unless required |
| Forms | HubSpot Forms, Airtable Forms, Tally, Fillout, or native site forms | Choose based on CRM routing needs |
| Lead storage | Airtable or HubSpot | Airtable for lightweight ops, HubSpot for sales pipeline |
| Testing | GA4 DebugView, GTM Preview, browser QA, mobile QA | Tracking is not optional |

## Landing-page templates to create

- Local restaurant location page
- Catering landing page
- Patticake product/order page
- Birthday Patticake page
- Thank-you cake page
- Corporate gifting page
- Wedding/event cake page
- Gift card page
- Paid ad landing page
- Review capture page

---

## Workflow D — Social asset production

| Need | Use | Notes |
|---|---|---|
| Master visual system | Figma | Brand rules, typography, layout grids, reusable modules |
| High-volume social templates | Canva Teams | Non-designers can edit/export quickly |
| Fast social variants | Canva AI / Magic Design | Use for layout variants, not fake food claims |
| AI image experimentation | Adobe Firefly | Use for concepting, backgrounds, overlays, not fake product proof |
| Short-form editing | CapCut, Adobe Express, Premiere Pro, or Descript | Choose based on team skill |
| Scheduling | Buffer | One calendar for Instagram, Facebook, TikTok, Pinterest, YouTube Shorts, and Google Business Profile |
| Asset library | Google Drive/Dropbox + Airtable index | Every asset needs usage rights, alt text, category, campaign, and approval status |

## Social templates to create

- 1080x1350 Instagram/Facebook feed post
- 1080x1080 square post
- 1080x1920 Reels/TikTok/Stories/Shorts frame
- 1000x1500 Pinterest Pin
- Google Business Profile post image
- Paid ad square
- Paid ad vertical
- Carousel template
- Review/testimonial template
- Catering lead-gen template
- Patticake birthday template
- Gift card promo template

## Production rule

Real food must look real. Use AI for layout, background cleanup, ideation, and resizing — not as a substitute for actual yum! food or Patticake product photography.

---

## Workflow E — Content calendar and publishing

| Need | Use | Notes |
|---|---|---|
| Content calendar database | Airtable | Content status, owner, channel, asset, caption, CTA, URL, UTM |
| Scheduling | Buffer | Publish and analyze from one calendar |
| Approval workflow | Airtable + Buffer approvals or ClickUp task statuses | Keep approvals out of text threads |
| Caption generation | ChatGPT | Generate variants; human edits for accuracy and voice |
| Caption QA | ChatGPT QA agent | Check CTA, URL, claims, spelling, offer accuracy |

## Airtable tables

1. Content Calendar
2. Asset Library
3. Caption Bank
4. Hook Bank
5. Campaigns
6. Creators/UGC
7. Paid Ad Variants
8. Landing Pages
9. UTMs
10. Approvals

---

## Workflow F — Lead capture and follow-up

| Need | Use | Notes |
|---|---|---|
| Catering lead forms | HubSpot Forms or Fillout/Tally → Airtable/HubSpot | Must capture UTM and event details |
| Corporate gifting leads | HubSpot | Better for sales pipeline and follow-up tasks |
| Wedding/event inquiries | HubSpot or Airtable | Need date, guest count, venue, status |
| Patticake requests | Existing ecommerce/form system + Airtable/HubSpot | Must be clear: order vs request |
| Restaurant customer email | Toast Marketing | Best tied to restaurant guest/order data if Toast is used |
| Automation routing | Zapier | Route leads to email, Slack, Airtable, HubSpot, Google Sheets |

## Lead pipeline stages

1. New
2. Reviewed
3. Contacted
4. Waiting on customer
5. Quoted
6. Won
7. Lost
8. Follow-up later

## Lead routing rules

| Lead Type | Destination |
|---|---|
| Catering | Catering owner + Airtable/HubSpot |
| Corporate gifting | Sales/ops owner + HubSpot |
| Wedding/event | Event/cake owner + HubSpot/Airtable |
| Patticake pickup | Bakery/order owner + Airtable |
| Shipping request | Bakery/shipping owner + Airtable |
| Review issue/private feedback | Store manager/general manager |

---

## Workflow G — Email and SMS

| Need | Use | Notes |
|---|---|---|
| Restaurant customer email | Toast Marketing | Order-linked restaurant campaigns |
| Catering/corporate/wedding nurture | HubSpot | Sales follow-up, sequences, lifecycle tagging |
| Ecommerce-style Patticake email | Klaviyo, Shopify Email, or HubSpot | Use Klaviyo if Patticake sits on Shopify or ecommerce checkout |
| SMS | Toast, Klaviyo, Attentive, Postscript, or HubSpot SMS features where available | Only use for high-intent/deadline messages |

## Email templates to create

- Welcome
- Second-order prompt
- Lapsed customer winback
- Catering lead follow-up
- Catering quote reminder
- Patticake gift reminder
- Birthday reminder
- Corporate gifting nurture
- Wedding/event inquiry follow-up
- Review request
- Holiday gifting deadline

---

## Workflow H — Analytics and reporting

| Need | Use | Notes |
|---|---|---|
| Tag deployment | Google Tag Manager | Centralized tracking implementation |
| Web analytics | GA4 | Events, conversions, traffic sources, landing-page performance |
| Dashboard | Looker Studio | Weekly acquisition dashboard |
| Paid social tracking | Meta Pixel + Conversions API | Use both where possible |
| Paid search tracking | Google Ads conversion tracking | Order clicks, calls, form submits, directions |
| UTM builder | Google Sheet/Airtable | Standardize campaign naming |
| QA | GTM Preview, GA4 DebugView, Meta Events Manager | Test every event before spend |

## Dashboard views

1. Executive summary
2. yum! local orders
3. Catering leads
4. Patticake orders/requests
5. Corporate gifting/wedding leads
6. Paid media performance
7. Organic/social performance
8. Email/SMS performance
9. Landing page conversion
10. Review and reputation growth

---

# 3. AI Model Routing Guide

Use different models/tools for different jobs. Do not make one model do everything.

| Job | Primary Model/Tool | Backup/Second Pass | Notes |
|---|---|---|---|
| Strategy and operating plans | ChatGPT / GPT-5-class reasoning model | Claude Opus/Sonnet | Best for synthesis, decision docs, prompt systems |
| Copywriting variants | ChatGPT | Claude | Generate many, then edit hard |
| Brand voice cleanup | ChatGPT custom GPT | Claude | Use approved source-of-truth doc as context |
| Long document analysis | ChatGPT or Gemini long-context model | Claude | Use when reviewing large docs, asset indexes, PDFs |
| Coding implementation | Cursor using top available coding model | GitHub Copilot coding agent / ChatGPT Codex | Always use branches and PRs |
| UI/component generation | v0 | Cursor | Useful for landing-page components |
| Code review | Claude / ChatGPT | GitHub Copilot | Use second model to critique the first model’s code |
| Data extraction / spreadsheet ops | ChatGPT / Gemini | Airtable AI | Best when converting forms, CSVs, dashboards |
| Image generation | ChatGPT image tools / Adobe Firefly / Canva AI | Human photo shoot | Never fake product photography as real |
| Video concepting | ChatGPT | Gemini / Adobe tools | Scripts, shot lists, hooks, captions |
| Social repurposing | ChatGPT + Buffer AI/Canva AI | Human editor | Convert one shoot into many posts |
| Automation building | Zapier Copilot/Agents | Make / custom code | Start no-code before writing custom integration code |

---

# 4. Recommended AI Agents to Build

## Agent 1 — Acquisition PM

**Use:** ChatGPT custom GPT or workspace agent

**Purpose:** Turn strategy into tickets, sprint plans, QA checklists, and weekly execution priorities.

**Inputs:** Backlog, sprint plan, current KPIs, blockers.

**Outputs:** Ticket list, owners, due dates, risks, weekly priorities.

---

## Agent 2 — Social Creative Director

**Use:** ChatGPT custom GPT

**Purpose:** Generate post concepts, hooks, captions, shot lists, and campaign briefs.

**Inputs:** Content pillars, brand rules, asset library, campaign goals.

**Outputs:** Calendar rows, captions, Reels scripts, Story frames, UGC briefs.

---

## Agent 3 — Social QA Agent

**Use:** ChatGPT custom GPT

**Purpose:** Check every asset before publishing.

**Checks:** CTA, URL, UTM, typo, unsupported claims, fake review, outdated hours/pricing, brand fit, mobile safe zone.

---

## Agent 4 — AI Coder PM

**Use:** ChatGPT + Cursor/GitHub

**Purpose:** Convert workstreams into AI-coder tickets.

**Outputs:** Ticket prompt, files likely affected, acceptance criteria, QA steps.

---

## Agent 5 — Funnel QA Agent

**Use:** ChatGPT + browser/testing notes

**Purpose:** Audit landing pages before paid traffic.

**Checks:** CTA clarity, conversion path, form behavior, event tracking, mobile experience, copy contradictions.

---

## Agent 6 — Analytics QA Agent

**Use:** ChatGPT + GA4/GTM event map

**Purpose:** Verify whether events match the analytics event map.

**Outputs:** Missing events, duplicate events, bad naming, missing UTM capture, dashboard gaps.

---

## Agent 7 — Catering Sales Assistant

**Use:** HubSpot Breeze/ChatGPT/Zapier depending on CRM stack

**Purpose:** Draft follow-up emails, summarize lead details, recommend next action.

**Rule:** Human approves replies until process is mature.

---

## Agent 8 — Creator/UGC Coordinator

**Use:** Airtable + ChatGPT + Zapier

**Purpose:** Manage creator outreach, deliverables, tracking codes, usage rights, deadlines, and scorecards.

---

# 5. Project Management Recommendation

## If the build is dev-heavy

Use **Linear + GitHub**.

Best for:
- AI coder tickets
- sprints
- PR-linked tasks
- clean engineering workflow

## If marketing + ops own most work

Use **ClickUp**.

Best for:
- social calendar
- approvals
- creative tasks
- launch timelines
- recurring checklists

## If the team needs simple documentation first

Use **Notion + Airtable**.

Best for:
- strategy docs
- source-of-truth pages
- content calendar
- easy team adoption

## Recommendation

Use:

- **Notion or Google Drive** for docs
- **Airtable** for databases
- **GitHub** for code
- **ClickUp or Linear** for execution

Do not use all three project-management apps at the same time.

---

# 6. Template Inventory to Build

## AI prompt templates

| Template | Tool | Purpose |
|---|---|---|
| Weekly Acquisition Review Prompt | ChatGPT | Turn KPIs into action plan |
| Social Post Generator Prompt | ChatGPT | Generate captions/hooks by pillar |
| Social QA Prompt | ChatGPT | Check assets before publishing |
| AI Coder Ticket Prompt | ChatGPT/Cursor | Convert task into code ticket |
| Landing Page QA Prompt | ChatGPT | Audit page before launch |
| UGC Brief Prompt | ChatGPT | Create creator briefs |
| Email Flow Prompt | ChatGPT | Draft lifecycle emails |
| Analytics QA Prompt | ChatGPT | Validate event map/dashboard |

## Design templates

| Template | Tool | Size |
|---|---|---|
| Instagram/Facebook feed | Canva/Figma | 1080x1350 |
| Square post | Canva/Figma | 1080x1080 |
| Reel/TikTok/Story/Short | Canva/Figma | 1080x1920 |
| Pinterest Pin | Canva/Figma | 1000x1500 |
| Google Business Profile post | Canva/Figma | 1200x900 or 1080x1080 |
| Paid vertical ad | Canva/Figma | 1080x1920 |
| Paid square ad | Canva/Figma | 1080x1080 |
| Carousel | Canva/Figma | 1080x1350 |

## Airtable templates

| Base | Tables |
|---|---|
| Content Calendar | Posts, Campaigns, Assets, Captions, Approvals, UTMs |
| Lead Tracker | Leads, Companies, Contacts, Stages, Owners, Sources |
| Asset Library | Assets, Usage Rights, Campaigns, Locations, Approval Status |
| Creator CRM | Creators, Outreach, Deliverables, Codes, Payments, Scores |
| Paid Creative Testing | Ads, Hooks, Visuals, Audiences, Metrics, Winners |

## Code templates

| Template | Purpose |
|---|---|
| `AI_CODER_TICKET_TEMPLATE.md` | Standard ticket prompt |
| `PULL_REQUEST_TEMPLATE.md` | PR summary + QA checklist |
| `ANALYTICS_EVENT_MAP.md` | Tracking reference |
| `FORM_FIELD_SPEC.md` | Form requirements |
| `LANDING_PAGE_TEMPLATE_SPEC.md` | Page acceptance criteria |
| `REDIRECT_MAP.csv` | Redirect/canonical rules |
| `.cursor/rules` | AI coding guardrails |

---

# 7. Budget Tiers

## Tier 1 — Lean founder/operator stack

Use this before proving the funnel.

| Category | Tool |
|---|---|
| AI | ChatGPT Pro |
| Code | Cursor Pro + GitHub |
| Design | Canva Pro/Teams |
| Ops database | Airtable |
| Scheduling | Buffer |
| Automation | Zapier |
| Analytics | GA4 + GTM + Looker Studio |
| Email | Toast Marketing + basic HubSpot/Airtable follow-up |

## Tier 2 — Growth stack

Use this once paid media and leads are flowing.

| Category | Tool |
|---|---|
| AI | ChatGPT Business |
| Code | Cursor Business + GitHub Copilot |
| Design | Figma + Canva Teams |
| CRM | HubSpot Starter/Professional |
| Restaurant email | Toast Marketing |
| Social | Buffer paid plan |
| Automations | Zapier Team |
| Analytics | GA4/GTM/Looker + Supermetrics or connector if needed |
| Creative | Adobe Express/Firefly + CapCut/Descript |

## Tier 3 — Scaled team stack

Use only if multiple locations, corporate gifting, catering, and paid media are all mature.

| Category | Tool |
|---|---|
| AI | ChatGPT Business/Enterprise + workspace agents |
| Code | Cursor Business + GitHub Enterprise/Copilot |
| CRM | HubSpot Professional/Enterprise |
| Social | Sprout Social or Buffer enterprise-level setup |
| Data | BigQuery or warehouse + Looker/Looker Studio |
| Asset management | Brandfolder, Bynder, or structured Drive/Dropbox + Airtable |
| Automation | Zapier Enterprise or Make + custom webhooks |

---

# 8. What Not to Buy or Build Yet

Do not buy/build these until the core funnel works:

- Full custom CRM
- Full custom ecommerce rebuild
- Enterprise social listening suite
- Expensive influencer marketplace
- Complex loyalty app
- Custom AI image model
- Custom marketing attribution platform
- Full mobile app
- Expensive DAM/PIM system
- Massive SEO blog engine before conversion pages exist

---

# 9. Implementation Order

## Week 1

1. Choose project hub.
2. Choose lead database.
3. Set up ChatGPT project/custom agents.
4. Set up GitHub repo/ticket templates.
5. Set up Airtable bases.
6. Set up Figma/Canva folder structure.
7. Set up GA4/GTM event map.

## Week 2

1. Build social design templates.
2. Build UTM builder.
3. Build content calendar.
4. Build lead forms.
5. Build Zapier routing.
6. Build first dashboards.

## Week 3

1. Launch Patticake and catering landing pages.
2. Start content production.
3. Load first 30 days into Buffer.
4. Start creator outreach.
5. Run tracking QA.

## Week 4

1. Launch paid traffic tests.
2. Review lead quality.
3. Kill weak creative.
4. Improve landing pages.
5. Automate follow-up.

---

# 10. Final Recommendation

Use this stack:

- **ChatGPT Business** as the AI command center.
- **Cursor + GitHub** for code execution.
- **v0** for landing-page/component prototypes.
- **Figma** for source design system.
- **Canva Teams** for production-ready social templates.
- **Airtable** for content, leads, assets, creators, UTMs.
- **HubSpot** for B2B lead pipeline if catering/corporate gifting volume justifies it.
- **Toast Marketing** for restaurant guest email.
- **Buffer** for social scheduling and analytics.
- **Zapier** for lead routing and automation.
- **GA4/GTM/Looker Studio** for measurement.

That gives the team speed without losing control.