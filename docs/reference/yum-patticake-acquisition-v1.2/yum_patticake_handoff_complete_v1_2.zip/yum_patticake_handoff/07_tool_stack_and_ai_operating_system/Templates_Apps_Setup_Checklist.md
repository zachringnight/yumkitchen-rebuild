# Templates, Apps, and Setup Checklist

## 1. Figma Templates

Create one Figma file named:

`yum_patticake_master_design_system.fig`

Pages:

1. Brand basics
2. Web components
3. Landing page wireframes
4. Social templates
5. Paid ad templates
6. Story/Reel covers
7. Catering campaign
8. Patticake campaign
9. Gift card campaign
10. QA examples

Required frames:

| Frame | Size | Use |
|---|---:|---|
| Feed portrait | 1080x1350 | Instagram/Facebook feed |
| Square | 1080x1080 | Social feed, paid square |
| Vertical video | 1080x1920 | Reels, Stories, TikTok, Shorts |
| Pinterest Pin | 1000x1500 | Pinterest |
| GBP post | 1200x900 | Google Business Profile |
| Landing page desktop | 1440 wide | Web design |
| Landing page mobile | 390 wide | Mobile design |

---

## 2. Canva Templates

Create Canva folders:

```text
01_yum_local
02_yum_catering
03_yum_bakery
04_patticake_birthday
05_patticake_gifting
06_patticake_corporate
07_patticake_weddings
08_gift_cards
09_paid_ads
10_story_templates
11_reel_covers
12_google_business_profile
```

Create editable templates:

- yum! menu feature
- yum! bakery case drop
- yum! catering quote
- yum! location spotlight
- yum! gift card
- Patticake birthday
- Patticake thank-you
- Patticake local pickup
- Patticake shipping
- Patticake corporate gifting
- Patticake wedding/event
- review/testimonial
- staff favorite
- limited-time seasonal drop
- paid ad square
- paid ad vertical
- Story CTA frame
- Reel cover

Each template must have:

- locked logo area
- editable headline
- editable subheadline
- image placeholder
- CTA area
- optional date/deadline
- optional location tag
- UTM destination note in speaker notes or metadata

---

## 3. Airtable Bases

## Base A — Content Calendar

Tables:

1. Posts
2. Campaigns
3. Assets
4. Captions
5. Hooks
6. Channels
7. CTAs
8. UTMs
9. Approvals
10. Performance

Important fields for Posts:

- post_id
- brand
- channel
- content_pillar
- campaign
- publish_date
- status
- owner
- asset_link
- caption
- hook
- CTA
- destination_url
- UTM_url
- approval_status
- performance_notes

## Base B — Lead Tracker

Tables:

1. Leads
2. Companies
3. Contacts
4. Opportunities
5. Campaign Sources
6. Follow-Up Tasks
7. Lost Reasons
8. Revenue

Important lead fields:

- lead_type
- source
- UTM fields
- name
- email
- phone
- company
- event_date
- guest_count
- quantity
- location_preference
- occasion
- status
- owner
- next_action_date
- won_revenue
- lost_reason

## Base C — Asset Library

Tables:

1. Assets
2. Shoots
3. Campaigns
4. Locations
5. Rights
6. Creators
7. Usage

Fields:

- file_name
- brand
- asset_type
- location
- campaign
- usage_rights
- approval_status
- alt_text
- recommended_channels
- raw_file_link
- edited_file_link

## Base D — Creator CRM

Tables:

1. Creators
2. Outreach
3. Deliverables
4. Codes
5. Payments
6. Usage Rights
7. Performance

---

## 4. Buffer Setup

Create channels:

- Instagram
- Facebook
- TikTok
- Pinterest
- YouTube Shorts
- Google Business Profile for each yum! location

Create content queues:

- yum! local
- yum! bakery
- yum! catering
- Patticake gifting
- Patticake corporate
- Patticake weddings/events
- Gift cards
- Reviews/testimonials
- Seasonal

Approval workflow:

1. Draft in Airtable/Canva
2. QA by Social QA Agent
3. Human approval
4. Schedule in Buffer
5. Post-performance added back to Airtable

---

## 5. HubSpot Setup

Use HubSpot if B2B follow-up matters. Recommended pipelines:

1. Catering Leads
2. Corporate Gifting Leads
3. Wedding/Event Leads

Lifecycle stages:

- Subscriber
- Lead
- Marketing Qualified Lead
- Sales Qualified Lead
- Opportunity
- Customer
- Repeat Customer

Lists:

- catering_leads
- corporate_gifting_leads
- wedding_event_leads
- patticake_shipping_leads
- cake_pickup_leads
- gift_card_interest
- birthday_reminder
- lapsed_customers

Workflows:

- Catering inquiry follow-up
- Corporate gifting nurture
- Wedding/event inquiry follow-up
- Birthday reminder
- Gift buyer reactivation
- Lapsed guest/customer winback

---

## 6. Toast Marketing Setup

Use for restaurant customer email tied to Toast guest/order data.

Flows:

- New guest welcome
- Second-order prompt
- Lapsed guest winback
- High-value guest thank-you
- Seasonal menu drop
- Gift card promotion
- Catering awareness campaign
- Bakery/cake awareness campaign

---

## 7. Zapier Automations

Build these first:

| Zap | Trigger | Action |
|---|---|---|
| Catering form → lead tracker | Form submit | Create Airtable/HubSpot lead + notify owner |
| Corporate gifting form → lead tracker | Form submit | Create HubSpot deal + notify owner |
| Wedding inquiry → lead tracker | Form submit | Create lead + assign event owner |
| Patticake request → bakery ops | Form submit | Create record + email/slack notification |
| Review issue → manager | Private feedback form submit | Notify manager immediately |
| Content approved → Buffer draft | Airtable status changes | Create scheduled/draft post if supported |
| New asset uploaded → asset index | Drive/Dropbox upload | Create Airtable asset record |
| Weekly KPIs → report prompt | Scheduled weekly | Pull data links + generate report task |

---

## 8. GA4/GTM Setup

Required events:

- order_click
- phone_click
- directions_click
- catering_form_submit
- patticake_shipping_request_submit
- cake_pickup_form_submit
- corporate_gifting_form_submit
- wedding_inquiry_submit
- gift_card_click
- email_signup_submit
- sms_signup_submit
- review_click
- social_profile_click

Every event should include:

- brand
- page_path
- CTA label
- destination_url
- location where relevant
- lead_type where relevant
- UTM fields where available

---

## 9. UTM Naming Template

Use lowercase and underscores.

```text
utm_source=instagram
utm_medium=organic_social
utm_campaign=patticake_birthday_q3_2026
utm_content=reel_pack_a_patticake
utm_term=na
```

Source examples:

- instagram
- facebook
- tiktok
- pinterest
- google
- google_business_profile
- email
- sms
- creator_[name]
- qr_pickup_bag
- qr_catering_box

Medium examples:

- organic_social
- paid_social
- paid_search
- email
- sms
- referral
- qr
- creator

Campaign examples:

- yum_catering_q3_2026
- patticake_birthday_q3_2026
- patticake_corporate_gifting_q4_2026
- yum_gift_cards_holiday_2026

---

## 10. Human Review Checkpoints

Human approval required before:

- publishing ads
- launching landing pages
- changing checkout/order copy
- publishing shipping/delivery claims
- publishing prices
- publishing allergen/gluten-free claims
- sending email/SMS campaigns
- responding publicly to negative reviews
- signing creator usage rights
- merging production code