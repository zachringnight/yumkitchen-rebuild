# QA Checklists

## Page Definition of Done

A page is not done until it has:

- Clear primary CTA.
- Clear secondary CTA where needed.
- Mobile-optimized layout.
- SEO title.
- Meta description.
- H1.
- Internal links.
- Image alt text.
- Tracking on all primary CTAs.
- UTM capture if form exists.
- Form success state if form exists.
- Error state if form exists.
- No placeholder content.
- No contradictory claims.
- Schema where relevant.
- Tested on desktop and mobile.
- Broken links checked.

## AI Coder QA Checklist

```text
QA Checklist:

1. Does the page render without console errors?
2. Does it work on mobile?
3. Does every CTA go to the correct destination?
4. Does every CTA fire the correct analytics event?
5. Do forms validate required fields?
6. Do forms submit successfully?
7. Are UTMs captured and passed through?
8. Are error states clear?
9. Are success states clear?
10. Are there any broken links?
11. Are there any placeholder reviews/images/copy?
12. Is SEO metadata present?
13. Is schema valid where relevant?
14. Did this ticket change unrelated pages?
15. Are all assumptions documented?
```

## Social Asset QA Checklist

- Brand fit.
- Correct logo/brand.
- Correct CTA.
- Correct URL.
- UTM included where needed.
- No typos.
- No placeholder copy.
- No unsupported operational claims.
- No outdated hours/prices.
- No fake reviews.
- No stock-looking creative.
- Mobile safe zones checked.
- Paid ad text not too crowded.
- Accessibility/alt text considered.
- File named correctly.
- Approved by owner.

## Paid Media Launch QA

- Landing page matches ad promise.
- CTA event fires.
- Lead form event fires.
- UTM parameters persist into form.
- Confirmation page or success event is measured.
- Call/directions/order links are correct.
- Mobile speed is acceptable.
- No homepage-only traffic unless intentional.
- No broad prospecting before funnel clarity.

## Patticake Funnel QA

- The page makes clear whether customer is ordering or requesting.
- Pickup vs shipping language is consistent.
- Shipping constraints are stated without overpromising.
- Gift message field is present if gifting is promoted.
- Occasion is captured.
- Corporate gifting and wedding/event upsells are present.
- No placeholder reviews.

## Catering Funnel QA

- Quote form has event date, time, guest count, location preference, company, and contact details.
- Form validates event date.
- Form routes to correct owner.
- Internal notification includes UTMs.
- Page includes packages, add-ons, notice requirements, pickup/location details, and dietary/allergen guidance.
